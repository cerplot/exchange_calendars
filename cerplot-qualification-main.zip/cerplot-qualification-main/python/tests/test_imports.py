"""Require the released Python 3.11 extension inventory, not just namespace imports."""
from __future__ import annotations

import importlib
import importlib.machinery
import unittest
from pathlib import Path
import sys


EXTENSIONS = (
    "cerplot.data._data_bind",
    "cerplot.cmtx._cmtx_bind",
    "cerplot.util._util_bind",
)


class ImportTests(unittest.TestCase):
    def assert_native_extension(self, name: str) -> None:
        module = importlib.import_module(name)
        filename = Path(module.__file__).resolve()
        self.assertTrue(any(str(filename).endswith(suffix)
                            for suffix in importlib.machinery.EXTENSION_SUFFIXES),
                        f"{name} is not a compiled Python extension: {filename}")
        self.assertTrue(filename.is_relative_to(Path(sys.prefix).resolve()),
                        f"{name} was imported outside the test venv")

    def test_data_extension(self) -> None:
        self.assert_native_extension(EXTENSIONS[0])

    def test_cmtx_extension(self) -> None:
        self.assert_native_extension(EXTENSIONS[1])

    def test_util_extension(self) -> None:
        self.assert_native_extension(EXTENSIONS[2])

    def test_public_package_namespaces(self) -> None:
        for name in ("cerplot", "cerplot.data", "cerplot.cmtx", "cerplot.util"):
            with self.subTest(module=name):
                self.assertIsNotNone(importlib.import_module(name))
