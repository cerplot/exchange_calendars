"""No CerPlot source tree, producer venv, or host-side installation is allowed."""
from __future__ import annotations

import importlib.metadata
import os
import sys
import unittest
from pathlib import Path


class InstalledWheelTests(unittest.TestCase):
    def test_is_a_fresh_virtual_environment(self) -> None:
        self.assertNotEqual(sys.prefix, sys.base_prefix, "not running inside a virtual environment")
        expected = Path(os.environ["CERPLOT_QUAL_VENV"]).resolve()
        self.assertEqual(Path(sys.prefix).resolve(), expected)

    def test_version_matches_release(self) -> None:
        expected = os.environ["CERPLOT_QUAL_VERSION"].removeprefix("v")
        self.assertEqual(importlib.metadata.version("cerplot"), expected)

    def test_package_imported_from_isolated_environment(self) -> None:
        import cerplot

        location = Path(cerplot.__file__).resolve()
        self.assertTrue(location.is_relative_to(Path(sys.prefix).resolve()),
                        f"CerPlot came from outside test venv: {location}")

    def test_developer_python_paths_are_not_inherited(self) -> None:
        self.assertNotIn("PYTHONPATH", os.environ)
        self.assertNotIn("PYTHONHOME", os.environ)
        self.assertNotIn("LD_LIBRARY_PATH", os.environ)
        self.assertNotIn("LD_PRELOAD", os.environ)
        self.assertFalse(any(k.startswith("CERPLOT_") and k.endswith("_PLUGIN")
                             for k in os.environ))
