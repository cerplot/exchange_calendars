"""Tests of the wheel installed into a fresh Python environment."""
