"""Fast infrastructure regressions; never require an installed CerPlot wheel."""
from __future__ import annotations

import hashlib
import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from bundle import BundleError, select_wheel  # noqa: E402
from environment import sanitized_environment  # noqa: E402
from reporting import write_json  # noqa: E402


class RunnerContractTests(unittest.TestCase):
    def create_bundle(self, root: Path, *, corrupt: bool = False) -> Path:
        wheel_path = "python/cerplot-0.1.8-cp311-cp311-manylinux_2_27_x86_64.whl"
        wheel = root / wheel_path
        wheel.parent.mkdir(parents=True)
        body = b"fake wheel for checksum selection test"
        wheel.write_bytes(body + (b"X" if corrupt else b""))
        sha = hashlib.sha256(body).hexdigest()
        write_json(root / "RELEASE.json", {
            "version": "v0.1.8",
            "artifacts": [{"path": wheel_path, "sha256": sha, "bytes": len(body)}],
        })
        (root / "SHA256SUMS").write_text(f"{sha}  {wheel_path}\n", encoding="utf-8")
        return wheel

    def test_valid_repaired_wheel(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            self.create_bundle(root)
            selected = select_wheel(root)
            self.assertEqual(selected["version"], "v0.1.8")
            self.assertTrue(selected["path"].name.endswith(".whl"))

    def test_rejects_modified_wheel(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            self.create_bundle(root, corrupt=True)
            with self.assertRaises(BundleError):
                select_wheel(root)

    def test_rejects_checksum_mismatch(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            self.create_bundle(root)
            (root / "SHA256SUMS").write_text("0" * 64 + "  python/cerplot-0.1.8-cp311-cp311-manylinux_2_27_x86_64.whl\n")
            with self.assertRaises(BundleError):
                select_wheel(root)

    def test_rejects_duplicate_manifest_entries(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            self.create_bundle(root)
            with (root / "SHA256SUMS").open("a", encoding="utf-8") as f:
                f.write((root / "SHA256SUMS").read_text(encoding="utf-8"))
            with self.assertRaises(BundleError):
                select_wheel(root)

    def test_strips_development_environment(self) -> None:
        with patch.dict("os.environ", {"PYTHONPATH": "/unwanted/python",
                                      "LD_LIBRARY_PATH": "/unwanted/lib",
                                      "CERPLOT_FACTOR_PLUGIN": "/unwanted/factor.so",
                                      "XDG_DATA_HOME": "/unwanted/data",
                                      "XDG_STATE_HOME": "/unwanted/state"}):
            env = sanitized_environment(Path("/tmp/isolated-qual"))
        self.assertNotIn("PYTHONPATH", env)
        self.assertNotIn("LD_LIBRARY_PATH", env)
        self.assertNotIn("CERPLOT_FACTOR_PLUGIN", env)
        self.assertEqual(env["PIP_NO_INDEX"], "1")
        self.assertEqual(env["XDG_DATA_HOME"], "/tmp/isolated-qual/data")
        self.assertEqual(env["XDG_STATE_HOME"], "/tmp/isolated-qual/state")


if __name__ == "__main__":
    unittest.main()
