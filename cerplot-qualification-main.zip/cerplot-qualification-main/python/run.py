#!/usr/bin/env python3
"""Qualify the Python wheel from an official CerPlot downloadable release."""
from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4

# Direct suite entry points must also locate the shared qualification helpers.
REPOSITORY_ROOT = Path(__file__).resolve().parents[1]
if str(REPOSITORY_ROOT) not in sys.path:
    sys.path.insert(0, str(REPOSITORY_ROOT))
from common.artifacts import release_identity
from bundle import BundleError, select_wheel
from environment import prepare_isolation, python_in_venv, run_logged
from reporting import Report

RUNNER_REVISION = "python-wheel-v1"
HERE = Path(__file__).resolve().parent


class QualificationError(RuntimeError):
    pass


def command_or_fail(report: Report, name: str, argv: list[str], run_dir: Path,
                    env: dict[str, str], timeout: int) -> None:
    result = run_logged(name=name, argv=argv, cwd=run_dir, env=env,
                        logs=run_dir / "logs", timeout=timeout)
    report.add_step(result)
    if result["status"] != "passed":
        raise QualificationError(f"{name} failed; see {result['log']}")


def create_run_directory(parent: Path) -> Path:
    """Always create a new unique child; never remove or overwrite previous runs."""
    parent.mkdir(parents=True, exist_ok=True)
    if parent.is_symlink() or not parent.is_dir():
        raise QualificationError("work directory cannot be a symlink")
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    run_dir = parent / f"python-{stamp}-{uuid4().hex[:8]}"
    run_dir.mkdir(mode=0o700, exist_ok=False)
    return run_dir


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bundle", type=Path, required=True,
                        help="Downloaded release containing RELEASE.json, SHA256SUMS, python/*.whl")
    parser.add_argument("--python", type=Path, required=True,
                        help="Python interpreter matching the released wheel (e.g. /usr/bin/python3.11)")
    parser.add_argument("--work-dir", type=Path, required=True,
                        help="Parent for new, preserved per-run test directories")
    parser.add_argument("--test", choices=("all", "installation", "imports"), default="all",
                        help="Development-only test selection; official acceptance uses all")
    parser.add_argument("--timeout", type=int, default=180,
                        help="Per-command timeout in seconds (default 180)")
    args = parser.parse_args(argv)
    if args.timeout < 1:
        parser.error("--timeout must be positive")
    if not args.python.is_file():
        parser.error("--python must identify an existing interpreter")
    # The test suite is owned by this repository, not by the released wheel.
    if not (HERE / "suite.py").is_file() or not (HERE / "tests/test_imports.py").is_file():
        parser.error("qualification test source is incomplete")
    bundle_root = args.bundle.expanduser().resolve()
    requested_work = args.work_dir.expanduser().absolute()
    if requested_work.resolve().is_relative_to(bundle_root):
        print("qualification setup failed: --work-dir must be outside the release bundle",
              file=sys.stderr)
        return 1
    try:
        run_dir = create_run_directory(requested_work)
    except (OSError, QualificationError) as exc:
        print(f"qualification setup failed: {exc}", file=sys.stderr)
        return 1
    report = Report(run_dir / "evidence/qualification.json", RUNNER_REVISION)
    try:
        env = prepare_isolation(run_dir)
        wheel = select_wheel(args.bundle.expanduser())
        identity = release_identity(bundle_root)
        if (identity["version"] != wheel["version"] or
                identity["artifacts"].get(wheel["relative_path"]) != wheel["sha256"]):
            raise QualificationError("wheel does not match the verified release inventory")
        report.data.update({
            "release_manifest_sha256": identity["release_manifest_sha256"],
            "release_checksums_sha256": identity["release_checksums_sha256"],
            "release_version": wheel["version"],
            "wheel_path": wheel["relative_path"],
            "wheel_sha256": wheel["sha256"],
            "wheel_bytes": wheel["bytes"],
            "python_requested": str(args.python.resolve()),
            "test_selection": args.test,
            "isolation": "fresh-venv-no-index-no-deps-sanitized-native-loader-env",
        })
        report.save()
        if args.test != "all":
            report.data["development_selection"] = True
            report.save()
        venv = run_dir / "venv"
        command_or_fail(report, "create-venv",
                        [str(args.python.resolve()), "-I", "-m", "venv", str(venv)],
                        run_dir, env, args.timeout)
        python = python_in_venv(venv)
        if not python.is_file():
            raise QualificationError("virtual environment did not create Python executable")
        command_or_fail(report, "install-wheel",
                        [str(python), "-I", "-m", "pip", "install", "--no-index",
                         "--no-deps", "--no-cache-dir", str(wheel["path"])],
                        run_dir, env, args.timeout)
        command_or_fail(report, "pip-check",
                        [str(python), "-I", "-m", "pip", "check"],
                        run_dir, env, args.timeout)
        suite_report = run_dir / "evidence/tests.json"
        test_env = dict(env)
        test_env["CERPLOT_QUAL_VERSION"] = wheel["version"]
        test_env["CERPLOT_QUAL_VENV"] = str(venv)
        command_or_fail(report, "unittest",
                        [str(python), "-I", str(HERE / "suite.py"),
                         "--tests-dir", str(HERE / "tests"),
                         "--report", str(suite_report),
                         "--test", args.test],
                        run_dir, test_env, args.timeout)
        if not suite_report.is_file():
            raise QualificationError("unittest did not write its result evidence")
        tests = json.loads(suite_report.read_text(encoding="utf-8"))
        if tests.get("status") != "passed" or tests.get("executed", 0) <= 0:
            raise QualificationError("unittest result evidence is not passing")
        # Selective testing is useful during development but not a release pass.
        report.data["tests"] = tests
        if args.test != "all":
            report.finish(False, "partial test selection is not official qualification")
            print(f"DEVELOPMENT TESTS PASSED (not qualified): {run_dir}")
            return 0
        report.finish(True)
        print(f"QUALIFIED PYTHON WHEEL: {wheel['version']} sha256={wheel['sha256']}")
        print(f"Evidence: {report.path}")
        print(f"Run directory: {run_dir}")
        return 0
    except (BundleError, QualificationError, OSError, ValueError, KeyError) as exc:
        report.finish(False, str(exc))
        print(f"PYTHON QUALIFICATION FAILED: {exc}", file=sys.stderr)
        print(f"Evidence: {report.path}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
