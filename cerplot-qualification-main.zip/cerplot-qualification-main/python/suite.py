#!/usr/bin/env python3
"""Run released-wheel unittest cases inside the fresh, installed venv."""
from __future__ import annotations

import argparse
import json
import os
import sys
import unittest
from pathlib import Path


class CountingResult(unittest.TextTestResult):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.successes = 0

    def addSuccess(self, test):
        super().addSuccess(test)
        self.successes += 1


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tests-dir", type=Path, required=True)
    parser.add_argument("--report", type=Path, required=True)
    parser.add_argument("--test", choices=["all", "installation", "imports"], default="all")
    args = parser.parse_args()
    pattern = "test_*.py" if args.test == "all" else f"test_{args.test}.py"
    loader = unittest.TestLoader()
    tests = loader.discover(start_dir=str(args.tests_dir.resolve()), pattern=pattern)
    runner = unittest.TextTestRunner(verbosity=2, resultclass=CountingResult)
    result = runner.run(tests)
    info = {
        "format": "cerplot-python-unittest-v1",
        "selection": args.test,
        "executed": result.testsRun,
        "passed": result.successes,
        "failures": len(result.failures),
        "errors": len(result.errors),
        "skipped": len(result.skipped),
        "expected_failures": len(result.expectedFailures),
        "unexpected_successes": len(result.unexpectedSuccesses),
        "status": "passed" if result.wasSuccessful() and result.testsRun > 0 and
                  not result.skipped and not result.expectedFailures else "failed",
    }
    args.report.parent.mkdir(parents=True, exist_ok=True)
    # Keep suite.py self-contained: Python -I does not include its script
    # directory in sys.path, and must not reintroduce it.
    pending = args.report.with_name(args.report.name + ".tmp")
    with pending.open("w", encoding="utf-8") as f:
        json.dump(info, f, sort_keys=True, indent=2)
        f.write("\n")
    os.replace(pending, args.report)
    return 0 if info["status"] == "passed" else 1


if __name__ == "__main__":
    sys.exit(main())
