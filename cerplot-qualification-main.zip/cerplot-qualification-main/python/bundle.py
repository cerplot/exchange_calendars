"""Select and verify a Python wheel in an existing CerPlot customer bundle."""
from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path
from typing import Any


HEX64 = re.compile(r"[0-9a-f]{64}\Z")
VERSION = re.compile(r"v[0-9]+\.[0-9]+\.[0-9]+(?:-[0-9A-Za-z][0-9A-Za-z.-]*)?\Z")
CHECKSUM = re.compile(r"([0-9a-f]{64})  ([^\r\n]+)\Z")


class BundleError(ValueError):
    pass


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as file:
        for chunk in iter(lambda: file.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _checksums(filename: Path) -> dict[str, str]:
    found: dict[str, str] = {}
    for line in filename.read_text(encoding="utf-8").splitlines():
        m = CHECKSUM.fullmatch(line)
        if not m:
            raise BundleError("invalid SHA256SUMS record")
        digest, path = m.groups()
        if path in found:
            raise BundleError("duplicate SHA256SUMS entry: " + path)
        found[path] = digest
    return found


def select_wheel(bundle: Path) -> dict[str, Any]:
    """Require official release inventory and verify the selected wheel's bytes.

    Supports the *downloaded* layout python/... and the assembler layout
    artifacts/python/.... Missing optional Dev SDK files do not affect this test.
    """
    bundle = bundle.resolve(strict=True)
    if not bundle.is_dir():
        raise BundleError("bundle is not a directory")
    release_file = bundle / "RELEASE.json"
    sums_file = bundle / "SHA256SUMS"
    if not release_file.is_file() or not sums_file.is_file():
        raise BundleError("release bundle requires RELEASE.json and SHA256SUMS")
    release = json.loads(release_file.read_text(encoding="utf-8"))
    if not isinstance(release, dict):
        raise BundleError("RELEASE.json must be an object")
    version = release.get("version")
    if not isinstance(version, str) or not VERSION.fullmatch(version):
        raise BundleError("invalid release version")
    entries = release.get("artifacts")
    if not isinstance(entries, list):
        raise BundleError("release artifacts are missing")
    candidates = [e for e in entries if isinstance(e, dict) and
                  isinstance(e.get("path"), str) and
                  e["path"].startswith("python/") and
                  e["path"].endswith(".whl") and
                  "manylinux_" in e["path"]]
    if len(candidates) != 1:
        raise BundleError("expected exactly one released repaired manylinux wheel")
    entry = candidates[0]
    relative = entry["path"]
    parts = relative.split("/")
    if len(parts) != 2 or parts[0] != "python" or parts[1] in {"", ".", ".."} or "/" in parts[1]:
        raise BundleError("unsafe wheel artifact path")
    if not re.fullmatch(r"cerplot-[0-9][A-Za-z0-9_.+\-]*\.whl", parts[1]):
        raise BundleError("unexpected wheel filename")
    expected = entry.get("sha256")
    if not isinstance(expected, str) or not HEX64.fullmatch(expected):
        raise BundleError("invalid wheel digest in RELEASE.json")
    suffix = relative
    selected_paths = [bundle / suffix, bundle / "artifacts" / suffix]
    present = [p for p in selected_paths if p.is_file() or p.is_symlink()]
    if len(present) != 1:
        raise BundleError("expected exactly one wheel location in release bundle")
    path = present[0]
    if path.is_symlink() or not path.is_file():
        raise BundleError("wheel must be a regular non-symlink file")
    if not path.resolve(strict=True).is_relative_to(bundle):
        raise BundleError("wheel escapes bundle root")
    manifest_name = path.relative_to(bundle).as_posix()
    sums = _checksums(sums_file)
    if sums.get(manifest_name) != expected:
        raise BundleError("wheel SHA256SUMS disagrees with RELEASE.json")
    if entry.get("bytes") != path.stat().st_size:
        raise BundleError("wheel size differs from release inventory")
    actual = sha256_file(path)
    if actual != expected:
        raise BundleError("wheel contents do not match release SHA-256")
    return {"version": version, "path": path, "sha256": expected,
            "relative_path": relative, "bytes": path.stat().st_size}
