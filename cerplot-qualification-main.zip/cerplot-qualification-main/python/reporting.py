"""Small, deterministic evidence records; no second release attestation system."""
from __future__ import annotations

import json
import os
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def write_json(path: Path, obj: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp")
    try:
        with temporary.open("w", encoding="utf-8") as stream:
            json.dump(obj, stream, sort_keys=True, indent=2)
            stream.write("\n")
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


class Report:
    def __init__(self, path: Path, runner_revision: str) -> None:
        self.path = path
        self.begin = time.monotonic()
        self.data: dict[str, Any] = {
            "format": "cerplot-python-qualification-v1",
            "status": "failed", "started_utc": utc_now(),
            "runner_revision": runner_revision,
            "steps": [],
        }
        self.save()

    def save(self) -> None:
        self.data["updated_utc"] = utc_now()
        self.data["elapsed_seconds"] = round(time.monotonic() - self.begin, 3)
        write_json(self.path, self.data)

    def add_step(self, step: dict[str, Any]) -> None:
        self.data["steps"].append(step)
        self.save()

    def finish(self, passed: bool, error: str | None = None) -> None:
        self.data["status"] = "passed" if passed else "failed"
        if error:
            self.data["error"] = error
        self.data["completed_utc"] = utc_now()
        self.save()
