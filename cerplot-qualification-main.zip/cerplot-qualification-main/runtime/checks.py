"""Validate the *existing* NSE local-profile and CerPlot process contracts."""
from __future__ import annotations

import json
import re
import sqlite3
import tomllib
from pathlib import Path

from bundle import QualificationError

SNAPSHOT_PREFIX = "CERPLOT::RUN_SNAPSHOT_PUBLISHED_V1 "
HEX64 = re.compile(r"[0-9a-f]{64}\Z")


def read_toml(path: Path) -> dict:
    if not path.is_file():
        raise QualificationError("Missing NSE configuration: " + str(path))
    with path.open("rb") as stream:
        return tomllib.load(stream)


def check_nse_profile(project: Path) -> dict:
    root = read_toml(project / "CerPlot.toml")
    local = root.get("run", {}).get("profiles", {}).get("local", {})
    if not isinstance(local, dict) or "run/local.toml" not in local.get("include", []):
        raise QualificationError("Released NSE configuration lacks run.profiles.local")
    for key in ("build", "worker", "scheduler", "store"):
        if local.get(key) != "local":
            raise QualificationError(f"NSE local profile must select {key}=local")
    conf = read_toml(project / "run/local.toml")
    run = conf.get("run", {})
    builds = run.get("builds", {}).get("local", {})
    if (builds.get("execution_mode") != "local" or builds.get("production") is not False
            or builds.get("fit_days") != 5 or builds.get("test_days") != 2
            or builds.get("gap_days") != 0 or builds.get("validation_days") != 0):
        raise QualificationError("NSE local profile is not the 5-fit/2-test research workload")
    if builds.get("plan") != "search.single.predictor_evaluation_v1":
        raise QualificationError("NSE local profile changed its expected research plan")
    assets_rel = builds.get("asset_list")
    if assets_rel != "data/assets2.txt":
        raise QualificationError("NSE local profile has unexpected asset list")
    assets = [x.strip() for x in (project / assets_rel).read_text(encoding="utf-8").splitlines()
              if x.strip() and not x.lstrip().startswith("#")]
    if len(assets) != 4 or len(set(assets)) != 4:
        raise QualificationError("NSE local profile must have four unique assets")
    if builds.get("sessions") != "data/dates.txt":
        raise QualificationError("NSE local profile has unexpected sessions file")
    sessions = {x.strip() for x in (project / "data/dates.txt").read_text().splitlines() if x.strip()}
    if builds.get("asof_date") not in sessions:
        raise QualificationError("NSE local asof_date is not in the session list")
    store = run.get("stores", {}).get("local", {})
    if store.get("manifest_backend") != "sqlite" or store.get("retention_backend") != "sqlite":
        raise QualificationError("NSE local store must use SQLite")
    for key in ("cas_root", "package_root", "manifest_sqlite_db_path", "retention_sqlite_db_path"):
        if "${CERPLOT_RUN_ROOT}" not in str(store.get(key, "")):
            raise QualificationError("NSE local store path is not isolated by CERPLOT_RUN_ROOT")
    for key in ("orchestrator_journal_db_path", "orchestrator_results_db_path"):
        if "${CERPLOT_RUN_ROOT}" not in str(builds.get(key, "")):
            raise QualificationError("NSE build state path is not isolated by CERPLOT_RUN_ROOT")
    workers = run.get("workers", {}).get("local", {})
    scheduler = run.get("schedulers", {}).get("local", {})
    if workers.get("executor_threads", 0) < 1 or scheduler.get("listen_host") != "127.0.0.1":
        raise QualificationError("NSE local worker or loopback scheduler is invalid")
    port = scheduler.get("listen_port")
    if not isinstance(port, int) or not 1024 <= port <= 65535:
        raise QualificationError("NSE local Scheduler port is invalid")
    local_env = project / "envfiles/config.local.linux.env"
    if not local_env.is_file():
        raise QualificationError("NSE local environment file is missing")
    environment_text = local_env.read_text(encoding="utf-8")
    # The current local env file can be comments-only. Machine defaults come
    # from ~/.cerplot.env, selected explicitly by the runner; the run root is
    # overridden in a generated project-local file. Do not require obsolete
    # CERPLOT_LOCAL_* indirection in released NSE sources.
    if re.search(r"(?m)^\s*(?:export\s+)?CERPLOT_[A-Z0-9_]+_PLUGIN\s*=", environment_text):
        raise QualificationError("NSE local environment contains manual plugin paths")
    if re.search(r"(?m)^\s*(?:export\s+)?CERPLOT_(?:DATA|RUN)_ROOT\s*=", environment_text):
        raise QualificationError("NSE local environment overrides the machine data or isolated run root")
    return {"assets": assets, "asset_count": 4, "fit_days": 5, "test_days": 2,
            "asof_date": builds["asof_date"], "plan": builds["plan"], "port": port}


def check_registry(runtime: Path) -> Path:
    registry = json.loads((runtime / "runtime-registry.json").read_text(encoding="utf-8"))
    if registry.get("schema_version") != 2 or not isinstance(registry.get("artifacts"), list):
        raise QualificationError("Expected sealed Runtime registry schema 2")
    host = [a for a in registry["artifacts"] if isinstance(a, dict)
            and a.get("component") == "Platform" and a.get("name") == "host"
            and a.get("kind") == "EXECUTABLE"]
    data = [a for a in registry["artifacts"] if isinstance(a, dict)
            and a.get("component") == "Data" and a.get("name") == "data.plugin"
            and a.get("kind") == "PLUGIN"]
    if len(host) != 1 or len(data) != 1:
        raise QualificationError("Research Runtime must register Platform.host and Data.data.plugin")
    relative = host[0].get("path")
    if not isinstance(relative, str) or relative.startswith("/") or ".." in Path(relative).parts:
        raise QualificationError("Unsafe registered Runtime executable path")
    exe = runtime / relative
    if not exe.is_file() or not exe.resolve().is_relative_to(runtime.resolve()):
        raise QualificationError("Registered CerPlot executable is missing or escapes Runtime")
    if not exe.stat().st_mode & 0o111:
        raise QualificationError("Packaged CerPlot executable is not executable")
    for metadata in ("MANIFEST.toml", "runtime-check-expectations.json"):
        if not (runtime / metadata).is_file():
            raise QualificationError("Missing Runtime qualification file: " + metadata)
    return exe


def check_inspect(path: Path) -> dict:
    try:
        result = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as error:
        raise QualificationError("Cannot parse CLI inspect JSON: " + str(error)) from error
    if result.get("validation", {}).get("valid") is not True or result.get("ok") is not True:
        raise QualificationError("NSE preflight inspection is not valid")
    if result.get("selected_profile") != "local":
        raise QualificationError("CLI did not select NSE local profile")
    classes = result.get("registry", {}).get("classes", [])
    if not isinstance(classes, list) or not any(isinstance(x, dict) and x.get("type") == "data"
                                                and x.get("class") == "tick" for x in classes):
        raise QualificationError("NSE preflight did not register data.tick")
    return {"selected_profile": "local", "registered_classes": len(classes), "data_tick": True}


def check_snapshot(build_log: Path, project: Path) -> dict:
    published = []
    with build_log.open("r", encoding="utf-8", errors="replace") as stream:
        for line in stream:
            if line.startswith(SNAPSHOT_PREFIX):
                try:
                    published.append(json.loads(line[len(SNAPSHOT_PREFIX):]))
                except ValueError as error:
                    raise QualificationError("Malformed run-snapshot publication") from error
    if len(published) != 1:
        raise QualificationError("Expected one RUN_SNAPSHOT_PUBLISHED_V1 record")
    record = published[0]
    digest = record.get("resolved_config_digest")
    path = record.get("run_snapshot_path")
    attempt_id = record.get("attempt_id")
    if not isinstance(digest, str) or not HEX64.fullmatch(digest):
        raise QualificationError("Invalid resolved configuration digest in run snapshot")
    if not isinstance(attempt_id, str) or not attempt_id or not isinstance(path, str):
        raise QualificationError("Invalid run-snapshot attempt or location")
    snapshot = Path(path)
    if not snapshot.is_file() or not snapshot.resolve().is_relative_to(project.resolve()):
        raise QualificationError("Build did not publish its snapshot inside isolated NSE project")
    return {"attempt_id": attempt_id, "resolved_config_digest": digest,
            "run_snapshot": str(snapshot.relative_to(project))}


def _sqlite_summary(path: Path) -> dict:
    if not path.is_file() or path.stat().st_size < 100:
        raise QualificationError("Required SQLite state missing: " + str(path))
    # Query read-only: do not create SQLite state merely by verifying it.
    with sqlite3.connect(f"file:{path.as_posix()}?mode=ro", uri=True, timeout=15) as db:
        if db.execute("PRAGMA quick_check").fetchone()[0] != "ok":
            raise QualificationError("SQLite integrity verification failed: " + str(path))
        tables = [x[0] for x in db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")]
        total = 0
        for name in tables:
            # Quoting is required even though names originate from sqlite_master.
            count = db.execute('SELECT COUNT(*) FROM "' + name.replace('"', '""') + '"').fetchone()[0]
            total += count
    if not tables or total == 0:
        raise QualificationError("Required SQLite state has no persisted rows: " + str(path))
    return {"tables": tables, "rows": total, "bytes": path.stat().st_size}


def check_results(run_root: Path) -> dict:
    results = _sqlite_summary(run_root / "db/results.sqlite")
    manifests = _sqlite_summary(run_root / "db/manifests.sqlite")
    cas_root = run_root / "cas"
    if not cas_root.is_dir():
        raise QualificationError("NSE CAS root was not created")
    count = 0
    size = 0
    for file in cas_root.rglob("*"):
        if file.is_symlink():
            raise QualificationError("CAS contains an unexpected symlink")
        if file.is_file():
            count += 1
            size += file.stat().st_size
    if count == 0 or size == 0:
        raise QualificationError("Build completed without any nonempty CAS artifacts")
    return {"results_sqlite": results, "manifest_sqlite": manifests,
            "cas_files": count, "cas_bytes": size}
