"""Offline regression tests for the runner; mock CLI is not product qualification."""
from __future__ import annotations

import hashlib
import io
import json
import os
import sqlite3
import subprocess
import sys
import tarfile
import tempfile
import unittest
import zipfile
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from bundle import QualificationError, select
from checks import check_nse_profile
from extract import extract_nse, extract_runtime
from process import execute, isolated_env


MOCK_CLI = r'''#!/usr/bin/env python3
import json, os, pathlib, sqlite3, sys
args = sys.argv[1:]
if args[0] == 'runtime-check':
    assert '--manifest' in args and '--expectations' in args
    sys.exit(0)
if args[0] == 'inspect':
    assert '--profile=local' in args and '--format=json' in args
    # A large machine-readable response with a diagnostic emitted on stderr
    # while stdout is in progress. Merging the channels corrupts the JSON.
    response = json.dumps({'ok':True,'selected_profile':'local',
                           'validation':{'valid':True},
                           'registry':{'classes':[{'type':'data','class':'tick'}]},
                           'description':'x'*255000})
    sys.stdout.write(response[:254080]); sys.stdout.flush()
    sys.stderr.write('logging.summary accepted=0 normal delivered=0\n'); sys.stderr.flush()
    sys.stdout.write(response[254080:]+'\n'); sys.stdout.flush()
    sys.exit(0)
assert args[0] == 'build' and '--profile=local' in args
assert all(not (x.startswith('CERPLOT_') and x.endswith('_PLUGIN')) for x in os.environ)
project = pathlib.Path(args[args.index('--project')+1])
assert os.environ['HOME'] != str(pathlib.Path(os.environ['CERPLOT_ENV_FILE']).parent)
assert os.environ['CERPLOT_CONFIG_ENV_FILE'] == 'envfiles/qualification.env'
assert 'CERPLOT_LOCAL_RUN_ROOT' not in os.environ
assert 'CERPLOT_DATA_ROOT' not in os.environ
machine_text = pathlib.Path(os.environ['CERPLOT_ENV_FILE']).read_text()
assert 'CERPLOT_DATA_ROOT=' in machine_text
project_text = (project / os.environ['CERPLOT_CONFIG_ENV_FILE']).read_text()
state = pathlib.Path(next(line.partition('=')[2] for line in project_text.splitlines()
                          if line.startswith('CERPLOT_RUN_ROOT=')))
assert state.is_absolute()
snap = project / '.cerplot/run1/run.toml'; snap.parent.mkdir(parents=True)
snap.write_text('run = 1')
print('CERPLOT::RUN_SNAPSHOT_PUBLISHED_V1 ' + json.dumps({'attempt_id':'abc', 'resolved_config_digest':'a'*64,'run_snapshot_path':str(snap)}), flush=True)
sys.stderr.write('logging.summary accepted=0 normal delivered=0\n'); sys.stderr.flush()
for name in ('results', 'manifests'):
    f=state/'db'/f'{name}.sqlite'; f.parent.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(f) as db:
        db.execute('CREATE TABLE rows (value INTEGER)'); db.execute('INSERT INTO rows VALUES (1)')
(state/'cas/one.cmtx').write_bytes(b'nonempty')
sys.exit(0)
'''


def fixture(root: Path) -> Path:
    """A valid *synthetic* release in the same manifest/archive shape."""
    (root / 'runtime').mkdir(parents=True)
    (root / 'sources').mkdir(parents=True)
    files = {
        'bin/cerplot': MOCK_CLI.encode(),
        'runtime-registry.json': json.dumps({'schema_version':2,'artifacts':[
            {'component':'Platform','name':'host','kind':'EXECUTABLE','path':'bin/cerplot'},
            {'component':'Data','name':'data.plugin','kind':'PLUGIN','path':'lib/data.so'}]}).encode(),
        'MANIFEST.toml': b'[product]\nname="mock"\n',
        'runtime-check-expectations.json': b'{}',
        'lib/data.so': b'fake',
    }
    runtime_name = 'runtime/cerplot-0.1.8-linux-x86_64-Release.tar.gz'
    with tarfile.open(root / runtime_name, 'w:gz') as tf:
        for name, value in files.items():
            meta=tarfile.TarInfo('runtime-prefix/'+name)
            meta.size=len(value)
            meta.mode=0o755 if name == 'bin/cerplot' else 0o644
            tf.addfile(meta, io.BytesIO(value))
    commit = 'a'*40
    nse_name=f'sources/config-nse-{commit[:12]}.zip'
    project_files = {
        'CerPlot.toml': '''[run]\nprofile="default"\n[run.profiles.local]\ninclude=["run/local.toml"]\nbuild="local"\nworker="local"\nscheduler="local"\nstore="local"\n''',
        'run/local.toml': '''[run.builds.local]\nexecution_mode="local"\nproduction=false\nplan="search.single.predictor_evaluation_v1"\nasof_date="2025-09-23"\nasset_list="data/assets2.txt"\nsessions="data/dates.txt"\nfit_days=5\ntest_days=2\ngap_days=0\nvalidation_days=0\norchestrator_journal_db_path="${CERPLOT_RUN_ROOT}/db/journal.sqlite"\norchestrator_results_db_path="${CERPLOT_RUN_ROOT}/db/results.sqlite"\n[run.workers.local]\nexecutor_threads=4\n[run.schedulers.local]\nlisten_host="127.0.0.1"\nlisten_port=18082\n[run.stores.local]\ncas_root="${CERPLOT_RUN_ROOT}/cas"\npackage_root="${CERPLOT_RUN_ROOT}/packages"\nmanifest_backend="sqlite"\nmanifest_sqlite_db_path="${CERPLOT_RUN_ROOT}/db/manifests.sqlite"\nretention_backend="sqlite"\nretention_sqlite_db_path="${CERPLOT_RUN_ROOT}/db/retention.sqlite"\n''',
        'envfiles/config.local.linux.env': '# Machine ~/.cerplot.env supplies data and run defaults.\n# No plugin overrides.\n',
        'data/assets2.txt': 'A\nB\nC\nD\n',
        'data/dates.txt': '2025-09-23\n',
    }
    with zipfile.ZipFile(root / nse_name, 'w') as z:
        for name, content in project_files.items():
            z.writestr('config-nse/'+name, content)
    entries=[]
    sums=[]
    for filename in (runtime_name, nse_name):
        f=root/filename
        digest=hashlib.sha256(f.read_bytes()).hexdigest()
        entries.append({'path':filename,'sha256':digest,'bytes':f.stat().st_size})
        sums.append(f'{digest}  {filename}\n')
    release={'format':'cerplot-rocky-single-toolchain-release-v2','version':'v0.1.8',
             'source_repositories':{'config-nse':{'branch':'main','commit':commit}},'artifacts':entries}
    (root/'RELEASE.json').write_text(json.dumps(release))
    (root/'SHA256SUMS').write_text(''.join(sums))
    return root


def machine_environment(root: Path) -> Path:
    user_home = root / "machine-home"
    user_home.mkdir(parents=True, exist_ok=True)
    data = root / "data"
    data.mkdir(parents=True, exist_ok=True)
    file = user_home / ".cerplot.env"
    file.write_text(f"CERPLOT_DATA_ROOT={data}\nCERPLOT_RUN_ROOT={root / 'ordinary-state'}\n",
                    encoding="utf-8")
    return file


class RunnerTests(unittest.TestCase):
    def test_execute_keeps_machine_stdout_separate_from_diagnostics(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            stdout = root / "inspect.stdout.json"
            script = ("import json,sys; "
                      "body=json.dumps({'ok':True,'payload':'x'*255000}); "
                      "sys.stdout.write(body[:254080]);sys.stdout.flush(); "
                      "sys.stderr.write('logging.summary accepted=0\\n');sys.stderr.flush(); "
                      "sys.stdout.write(body[254080:]+'\\n');sys.stdout.flush()")
            record = execute("inspect", [sys.executable, "-c", script],
                             root, os.environ.copy(), stdout, 15)
            self.assertEqual(record["status"], "passed")
            self.assertEqual(record["log"], "logs/inspect.stdout.json")
            self.assertEqual(record["stderr_log"], "logs/inspect.stderr.log")
            self.assertTrue(json.loads(stdout.read_text())["ok"])
            stderr = (root / "inspect.stderr.log").read_text()
            self.assertEqual(stderr, "logging.summary accepted=0\n")
            self.assertNotIn("logging.summary", stdout.read_text())

    def test_select_exact_downloaded_artifacts(self):
        with tempfile.TemporaryDirectory() as tmp:
            bundle=fixture(Path(tmp))
            result=select(bundle)
            self.assertEqual(result['version'],'v0.1.8')
            self.assertEqual(result['commit'],'a'*40)

    def test_reject_artifact_tampering(self):
        with tempfile.TemporaryDirectory() as tmp:
            bundle=fixture(Path(tmp))
            (bundle/'sources/config-nse-aaaaaaaaaaaa.zip').write_bytes(b'tampered')
            with self.assertRaises(QualificationError): select(bundle)

    def test_reject_release_source_mismatch(self):
        with tempfile.TemporaryDirectory() as tmp:
            bundle=fixture(Path(tmp))
            data=json.loads((bundle/'RELEASE.json').read_text())
            data['source_repositories']['config-nse']['commit']='b'*40
            (bundle/'RELEASE.json').write_text(json.dumps(data))
            with self.assertRaises(QualificationError): select(bundle)

    def test_reject_zip_traversal(self):
        with tempfile.TemporaryDirectory() as tmp:
            archive=Path(tmp)/'bad.zip'
            with zipfile.ZipFile(archive,'w') as z:
                z.writestr('config-nse/../bad','bad')
            with self.assertRaises(QualificationError): extract_nse(archive, Path(tmp)/'out')

    def test_reject_tar_traversal(self):
        with tempfile.TemporaryDirectory() as tmp:
            archive=Path(tmp)/'bad.tar.gz'
            with tarfile.open(archive,'w:gz') as tf:
                item=tarfile.TarInfo('../escape'); item.size=1
                tf.addfile(item, io.BytesIO(b'x'))
            with self.assertRaises(QualificationError): extract_runtime(archive, Path(tmp)/'out')

    def test_profile_contract(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=fixture(Path(tmp))
            project=extract_nse(root/'sources/config-nse-aaaaaaaaaaaa.zip', root/'project')
            self.assertEqual(check_nse_profile(project)['asset_count'],4)
            local=project/'run/local.toml'; local.write_text(local.read_text().replace('fit_days=5','fit_days=3'))
            with self.assertRaises(QualificationError): check_nse_profile(project)

    def test_full_synthetic_execution(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            bundle=root/'bundle'; fixture(bundle)
            data=root/'data'; machine_file=machine_environment(root)
            command=[sys.executable,str(ROOT/'run.py'),'--bundle',str(bundle),
                     '--machine-env-file',str(machine_file),'--data-root',str(data),'--work-dir',str(root/'work'),
                     '--timeout-smoke','15','--timeout-build','15']
            res=subprocess.run(command,capture_output=True,text=True,timeout=50)
            self.assertEqual(res.returncode,0,res.stdout+'\n'+res.stderr)
            reports=list((root/'work').glob('*/evidence/qualification.json'))
            self.assertEqual(len(reports),1)
            evidence=json.loads(reports[0].read_text())
            self.assertEqual(evidence['status'],'passed')
            self.assertEqual([x['name'] for x in evidence['steps']],
                             ['runtime-check','inspect','build'])
            self.assertGreater(evidence['outputs']['cas_files'],0)
            inspect_step = next(step for step in evidence['steps']
                                if step['name'] == 'inspect')
            self.assertEqual(inspect_step['log'], 'logs/inspect.stdout.json')
            self.assertEqual(inspect_step['stderr_log'], 'logs/inspect.stderr.log')
            self.assertIn('logging.summary', (reports[0].parents[1] /
                       inspect_step['stderr_log']).read_text())
            inspect_json = reports[0].parent / 'inspect.json'
            self.assertEqual(json.loads(inspect_json.read_text())['selected_profile'], 'local')
            self.assertGreater(inspect_json.stat().st_size, 254080)
            build_step = next(step for step in evidence['steps']
                              if step['name'] == 'build')
            self.assertIn('CERPLOT::RUN_SNAPSHOT_PUBLISHED_V1',
                          (reports[0].parents[1] / build_step['log']).read_text())
            self.assertIn('logging.summary',
                          (reports[0].parents[1] / build_step['stderr_log']).read_text())
            from common.artifacts import release_identity
            identity = release_identity(bundle)
            self.assertEqual(evidence['release_manifest_sha256'], identity['release_manifest_sha256'])
            self.assertEqual(evidence['release_checksums_sha256'], identity['release_checksums_sha256'])

    def test_full_failure_is_not_a_pass(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); bundle=root/'bundle'; fixture(bundle)
            data=root/'data'; machine_file=machine_environment(root)
            # Corrupt the local profile, regenerate the archive SHA and release
            # entry to exercise the *configuration* validator after input integrity.
            zip_path=bundle/'sources/config-nse-aaaaaaaaaaaa.zip'
            with zipfile.ZipFile(zip_path) as z:
                members={name:z.read(name) for name in z.namelist()}
            members['config-nse/run/local.toml']=members['config-nse/run/local.toml'].replace(b'fit_days=5',b'fit_days=3')
            with zipfile.ZipFile(zip_path,'w') as z:
                for name,value in members.items(): z.writestr(name,value)
            release=json.loads((bundle/'RELEASE.json').read_text())
            sha=hashlib.sha256(zip_path.read_bytes()).hexdigest()
            for entry in release['artifacts']:
                if entry['path'].startswith('sources/'):
                    entry['sha256']=sha; entry['bytes']=zip_path.stat().st_size
            (bundle/'RELEASE.json').write_text(json.dumps(release))
            (bundle/'SHA256SUMS').write_text(''.join(
                f'{e["sha256"]}  {e["path"]}\n' for e in release['artifacts']))
            res=subprocess.run([sys.executable,str(ROOT/'run.py'),'--bundle',str(bundle),
                                '--machine-env-file',str(machine_file),'--data-root',str(data),'--work-dir',str(root/'work')],
                               capture_output=True,text=True,timeout=30)
            self.assertNotEqual(res.returncode,0)
            report=list((root/'work').glob('*/evidence/qualification.json'))[0]
            self.assertEqual(json.loads(report.read_text())['status'],'failed')

    def test_preflight_never_counts_as_complete(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); bundle=root/'bundle'; fixture(bundle)
            data=root/'data'; machine_file=machine_environment(root)
            res=subprocess.run([sys.executable,str(ROOT/'run.py'),'--bundle',str(bundle),
                                '--machine-env-file',str(machine_file),'--data-root',str(data),'--work-dir',str(root/'work'),
                                '--mode','preflight','--timeout-smoke','15'],
                               capture_output=True,text=True,timeout=30)
            self.assertEqual(res.returncode,0,res.stderr)
            report=list((root/'work').glob('*/evidence/qualification.json'))[0]
            evidence=json.loads(report.read_text())
            self.assertEqual(evidence['status'],'preflight-passed-not-full-qualification')
            self.assertEqual([step['name'] for step in evidence['steps']],
                             ['runtime-check','inspect'])

    def test_missing_data_plugin_default_is_not_added(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); bundle=root/'bundle'; fixture(bundle)
            data=root/'data'; machine_file=machine_environment(root)
            env=os.environ.copy()
            env['CERPLOT_DATA_PLUGIN']='/nonexistent/extension.so'
            res=subprocess.run([sys.executable,str(ROOT/'run.py'),'--bundle',str(bundle),
                                '--machine-env-file',str(machine_file),'--data-root',str(data),'--work-dir',str(root/'work'),
                                '--timeout-smoke','15','--timeout-build','15'],
                               env=env,capture_output=True,text=True,timeout=30)
            self.assertEqual(res.returncode,0,res.stderr)

    def test_workdir_under_release_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); bundle=root/'bundle'; fixture(bundle)
            data=root/'data'; machine_file=machine_environment(root)
            res=subprocess.run([sys.executable,str(ROOT/'run.py'),'--bundle',str(bundle),
                                '--machine-env-file',str(machine_file),'--data-root',str(data),'--work-dir',str(bundle/'bad')],
                               capture_output=True,text=True,timeout=15)
            self.assertNotEqual(res.returncode,0)
            self.assertFalse((bundle/'bad').exists())

    def test_comment_only_nse_local_env_is_valid(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            bundle = fixture(root)
            project = extract_nse(bundle / 'sources/config-nse-aaaaaaaaaaaa.zip', root / 'nse')
            local = project / 'envfiles/config.local.linux.env'
            self.assertFalse(any(line.strip() and not line.lstrip().startswith('#')
                                 for line in local.read_text().splitlines()))
            self.assertEqual(check_nse_profile(project)['asset_count'], 4)
            local.write_text('CERPLOT_DATA_ROOT=/unexpected\n')
            with self.assertRaisesRegex(QualificationError, 'overrides'):
                check_nse_profile(project)

    def test_machine_plugin_overrides_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            bundle = fixture(root / 'bundle')
            machine_file = machine_environment(root)
            with machine_file.open('a') as f:
                f.write('CERPLOT_FACTOR_PLUGIN=/outside/override.so\n')
            res = subprocess.run([sys.executable, str(ROOT / 'run.py'),
                                  '--bundle', str(bundle), '--work-dir', str(root / 'runs'),
                                  '--machine-env-file', str(machine_file)],
                                 capture_output=True, text=True)
            self.assertNotEqual(res.returncode, 0)
            self.assertIn('bundled defaults would not be tested', res.stderr)

    def test_machine_project_env_selector_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            bundle = fixture(root / 'bundle')
            machine_file = machine_environment(root)
            with machine_file.open('a') as f:
                f.write('CERPLOT_CONFIG_ENV_FILE=envfiles/wrong.env\n')
            res = subprocess.run([sys.executable, str(ROOT / 'run.py'),
                                  '--bundle', str(bundle), '--work-dir', str(root / 'runs'),
                                  '--machine-env-file', str(machine_file)],
                                 capture_output=True, text=True)
            self.assertNotEqual(res.returncode, 0)
            self.assertIn('would override isolated qualification state', res.stderr)

    def test_default_machine_home_env_selection(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            bundle = fixture(root / 'bundle')
            machine_file = machine_environment(root)
            env = os.environ.copy()
            env['HOME'] = str(machine_file.parent)
            res = subprocess.run([sys.executable, str(ROOT / 'run.py'),
                                  '--bundle', str(bundle), '--work-dir', str(root / 'runs'),
                                  '--mode', 'preflight', '--timeout-smoke', '15'],
                                 env=env, capture_output=True, text=True)
            self.assertEqual(res.returncode, 0, res.stdout + res.stderr)
            report = next((root / 'runs').glob('*/evidence/qualification.json'))
            record = json.loads(report.read_text())
            self.assertEqual(record['machine_env_file'], str(machine_file))
            self.assertEqual(record['status'], 'preflight-passed-not-full-qualification')

    def test_runtime_extraction_preserves_internal_symlink(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); archive=root/'runtime.tar.gz'
            with tarfile.open(archive,'w:gz') as tf:
                item=tarfile.TarInfo('./'); item.type=tarfile.DIRTYPE
                tf.addfile(item)
                for name,content in [('runtime-registry.json',b'{}'),('MANIFEST.toml',b'')]:
                    info=tarfile.TarInfo('./'+name); info.size=len(content)
                    tf.addfile(info,io.BytesIO(content))
                info=tarfile.TarInfo('./lib/libactual.so'); info.size=1
                tf.addfile(info,io.BytesIO(b'a'))
                info=tarfile.TarInfo('./lib/libalias.so'); info.type=tarfile.SYMTYPE
                info.linkname='libactual.so'; tf.addfile(info)
            product=extract_runtime(archive,root/'out')
            self.assertEqual((product/'lib/libalias.so').read_bytes(),b'a')

    def test_runtime_archive_external_symlink_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); archive=root/'bad.tar.gz'
            with tarfile.open(archive,'w:gz') as tf:
                info=tarfile.TarInfo('lib/link.so'); info.type=tarfile.SYMTYPE
                info.linkname='../../../../etc/passwd'; tf.addfile(info)
            with self.assertRaises(QualificationError): extract_runtime(archive,root/'out')


class RuntimeArchiveLinkTests(unittest.TestCase):
    @staticmethod
    def _archive(folder: Path, additions: list[tuple[str, str, bytes | str]]) -> Path:
        archive = folder / "candidate.tar.gz"
        with tarfile.open(archive, "w:gz") as tar:
            for name, content in (("runtime-registry.json", b"{}"), ("MANIFEST.toml", b"")):
                item = tarfile.TarInfo(name)
                item.size = len(content)
                tar.addfile(item, io.BytesIO(content))
            for name, kind, content in additions:
                item = tarfile.TarInfo(name)
                if kind == "file":
                    assert isinstance(content, bytes)
                    item.size = len(content)
                    tar.addfile(item, io.BytesIO(content))
                elif kind in {"symlink", "hardlink"}:
                    assert isinstance(content, str)
                    item.type = tarfile.SYMTYPE if kind == "symlink" else tarfile.LNKTYPE
                    item.linkname = content
                    tar.addfile(item)
                else:
                    raise AssertionError(kind)
        return archive

    def test_two_link_elf_symlink_chain_both_member_orders(self):
        for reverse in (False, True):
            with self.subTest(reverse=reverse), tempfile.TemporaryDirectory() as td:
                root = Path(td)
                links = [("lib/libdemo.so", "symlink", "libdemo.so.1"),
                         ("lib/libdemo.so.1", "symlink", "libdemo.so.1.0")]
                if reverse:
                    links.reverse()
                archive = self._archive(root, links + [("lib/libdemo.so.1.0", "file", b"payload")])
                product = extract_runtime(archive, root / "out")
                self.assertEqual((product / "lib/libdemo.so").read_bytes(), b"payload")

    def test_hard_links_forward_reference_and_chain(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            archive = self._archive(root, [
                ("lib/first.so", "hardlink", "lib/second.so"),
                ("lib/second.so", "hardlink", "lib/real.so"),
                ("lib/real.so", "file", b"bytes"),
                ("lib/name.so", "symlink", "first.so"),
            ])
            product = extract_runtime(archive, root / "out")
            self.assertEqual((product / "lib/name.so").read_bytes(), b"bytes")
            self.assertEqual((product / "lib/first.so").stat().st_ino,
                             (product / "lib/real.so").stat().st_ino)

    def test_dangling_symlink_is_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            archive = self._archive(root, [("lib/missing.so", "symlink", "absent.so")])
            with self.assertRaises(QualificationError):
                extract_runtime(archive, root / "out")

    def test_symlink_cycle_is_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            archive = self._archive(root, [
                ("lib/a.so", "symlink", "b.so"),
                ("lib/b.so", "symlink", "a.so"),
            ])
            with self.assertRaises(QualificationError):
                extract_runtime(archive, root / "out")

    def test_existing_target_outside_destination_is_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            (root / "external").write_bytes(b"should-not-be-reachable")
            archive = self._archive(root, [("lib/link.so", "symlink", "../../external")])
            with self.assertRaises(QualificationError):
                extract_runtime(archive, root / "out")
            self.assertEqual((root / "external").read_bytes(), b"should-not-be-reachable")

    def test_nested_archive_link_does_not_write_through_symlink_parent(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            archive = self._archive(root, [
                ("lib/ref", "symlink", ".."),
                ("lib/ref/child.so", "symlink", "../lib/real.so"),
                ("lib/real.so", "file", b"ok"),
            ])
            with self.assertRaises(QualificationError):
                extract_runtime(archive, root / "out")

    def test_escape_and_cycle_hard_links_are_rejected(self):
        for additions in (
            [("lib/a", "hardlink", "../escape")],
            [("lib/a", "hardlink", "lib/b"), ("lib/b", "hardlink", "lib/a")],
        ):
            with self.subTest(additions=additions), tempfile.TemporaryDirectory() as td:
                root = Path(td)
                with self.assertRaises(QualificationError):
                    extract_runtime(self._archive(root, additions), root / "out")


class RuntimeEnvironmentIsolationTests(unittest.TestCase):
    def test_all_xdg_locations_override_inherited_settings(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            home = root / "home"
            home.mkdir()
            data = root / "data"
            state = root / "state"
            machine_file = root / ".cerplot.env"
            machine_file.write_text("CERPLOT_DATA_ROOT=/mnt/nse\n", encoding="utf-8")
            with patch.dict(os.environ, {
                "XDG_CONFIG_HOME": "/outside/config",
                "XDG_CACHE_HOME": "/outside/cache",
                "XDG_DATA_HOME": "/outside/data",
                "XDG_STATE_HOME": "/outside/state",
                "CERPLOT_FACTOR_PLUGIN": "/outside/unwanted.so",
            }):
                env = isolated_env(home, machine_file)
            for name in ("XDG_CONFIG_HOME", "XDG_CACHE_HOME", "XDG_DATA_HOME", "XDG_STATE_HOME"):
                target = Path(env[name])
                self.assertTrue(target.is_relative_to(home), name)
                self.assertTrue(target.is_dir(), name)
            self.assertNotIn("CERPLOT_FACTOR_PLUGIN", env)
            self.assertEqual(env["CERPLOT_ENV_FILE"], str(machine_file))
            self.assertEqual(env["CERPLOT_CONFIG_ENV_FILE"], "envfiles/qualification.env")
            self.assertNotIn("CERPLOT_LOCAL_DATA_ROOT", env)
            self.assertNotIn("CERPLOT_LOCAL_RUN_ROOT", env)


if __name__ == '__main__':
    unittest.main()
