#!/usr/bin/env python3
"""Qualify a downloaded CerPlot Runtime with the shipped config-nse local profile.

Linux, Python 3.11+, standard library only. No CerPlot SDK, source tree,
Git checkout, package manager, or remote network required.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import socket
import sys
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4

REPOSITORY_ROOT = Path(__file__).resolve().parents[1]
if str(REPOSITORY_ROOT) not in sys.path:
    sys.path.insert(0, str(REPOSITORY_ROOT))
from common.artifacts import release_identity
from bundle import QualificationError, select
from checks import check_inspect, check_nse_profile, check_registry, check_results, check_snapshot
from extract import extract_nse, extract_runtime
from process import execute, isolated_env

REVISION = "runtime-nse-v1"


def save_json(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    try:
        temporary.write_text(json.dumps(data, sort_keys=True, indent=2) + "\n", encoding="utf-8")
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def fresh_run(parent: Path) -> Path:
    # Avoid deletion entirely; prior evidence/run state is never reused.
    if parent.is_symlink():
        raise QualificationError("Work directory cannot be a symlink")
    parent.mkdir(parents=True, exist_ok=True)
    name = datetime.now(timezone.utc).strftime("runtime-%Y%m%dT%H%M%SZ-") + uuid4().hex[:10]
    directory = parent / name
    directory.mkdir(mode=0o700)
    for sub in ("logs", "evidence", "home", "home/tmp", "state", "unpacked"):
        (directory / sub).mkdir(mode=0o700, parents=True)
    return directory


def assert_port_available(port: int) -> None:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        try:
            sock.bind(("127.0.0.1", port))
        except OSError as err:
            raise QualificationError(f"NSE local scheduler port {port} is unavailable: {err}") from err


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bundle", type=Path, required=True,
                        help="Downloaded release root containing RELEASE.json and SHA256SUMS")
    parser.add_argument("--machine-env-file", type=Path,
                        help="Machine dotenv file (default: invoking user's ~/.cerplot.env)")
    parser.add_argument("--data-root", type=Path,
                        help="Optional read-only data-directory assertion; does not set CERPLOT_DATA_ROOT")
    parser.add_argument("--work-dir", type=Path, required=True,
                        help="Parent directory for fresh per-run qualification state")
    parser.add_argument("--mode", choices=("full", "preflight"), default="full",
                        help="Only full counts as research qualification")
    parser.add_argument("--timeout-build", type=int, default=7200,
                        help="Research build timeout in seconds (default 7200)")
    parser.add_argument("--timeout-smoke", type=int, default=120,
                        help="Runtime-check/inspect timeout in seconds (default 120)")
    args = parser.parse_args(argv)
    if sys.platform != "linux":
        parser.error("The official Runtime/NSE suite currently supports Linux only")
    if min(args.timeout_build, args.timeout_smoke) < 1:
        parser.error("Both timeout values must be positive")
    try:
        bundle = args.bundle.expanduser().resolve(strict=True)
        # Resolve BEFORE replacing HOME with the isolated process home. Core's
        # own CERPLOT_ENV_FILE selector then reads this file normally.
        machine_env_file = (args.machine_env_file or (Path.home() / ".cerplot.env"))
        machine_env_file = machine_env_file.expanduser().resolve(strict=True)
        if not machine_env_file.is_file():
            raise QualificationError("Machine CerPlot environment file is not a regular file")
        machine_contents = machine_env_file.read_text(encoding="utf-8")
        if not re.search(r"(?m)^\s*(?:export\s+)?CERPLOT_DATA_ROOT\s*=", machine_contents):
            raise QualificationError("Machine ~/.cerplot.env must define CERPLOT_DATA_ROOT")
        if re.search(r"(?m)^\s*(?:export\s+)?CERPLOT_[A-Z0-9_]+_PLUGIN\s*=", machine_contents):
            raise QualificationError("Machine environment file defines plugin paths; bundled defaults would not be tested")
        if re.search(r"(?m)^\s*(?:export\s+)?CERPLOT_CONFIG_ENV_FILE\s*=", machine_contents):
            raise QualificationError("Machine environment file selects a project dotenv and would override isolated qualification state")
        data_root = (args.data_root.expanduser().resolve(strict=True)
                     if args.data_root is not None else None)
        work = args.work_dir.expanduser().absolute()
        if data_root is not None and not data_root.is_dir():
            raise QualificationError("Asserted historical NSE data root is not a directory")
        if not bundle.is_dir():
            raise QualificationError("Release bundle is not a directory")
        # Do not write into either read-only input tree or their ancestors.
        resolved_work = work.resolve()
        if machine_env_file.is_relative_to(resolved_work):
            raise QualificationError("--work-dir contains the machine environment file")
        for protected in (bundle, data_root):
            if protected is not None and (resolved_work == protected
                    or resolved_work.is_relative_to(protected)
                    or protected.is_relative_to(resolved_work)):
                raise QualificationError("--work-dir overlaps a release or historical-data input")
        run = fresh_run(work)
    except (OSError, QualificationError) as err:
        print("RUNTIME QUALIFICATION SETUP FAILED: " + str(err), file=sys.stderr)
        return 1

    report_file = run / "evidence/qualification.json"
    evidence: dict = {
        "format": "cerplot-runtime-nse-qualification-v1",
        "runner_revision": REVISION,
        "status": "failed",
        "started_utc": datetime.now(timezone.utc).isoformat(),
        "mode": args.mode,
        "steps": [],
    }
    save_json(report_file, evidence)

    def step(name: str, command: list[str], cwd: Path, env: dict[str, str], timeout: int) -> Path:
        output = run / "logs" / (name + (".stdout.json" if name == "inspect"
                                          else ".stdout.log"))
        result = execute(name, command, cwd, env, output, timeout)
        evidence["steps"].append(result)
        save_json(report_file, evidence)
        if result["status"] != "passed":
            raise QualificationError(f"{name} failed or timed out; see {output} "
                                     f"and {run / result['stderr_log']}")
        return output

    try:
        inputs = select(bundle)
        identity = release_identity(bundle)
        if (identity["version"] != inputs["version"] or
                any(identity["artifacts"].get(inputs[name]["relative"]) != inputs[name]["sha256"]
                    for name in ("runtime", "nse"))):
            raise QualificationError("Runtime/NSE inputs do not match the release inventory")
        evidence.update({
            "release_manifest_sha256": identity["release_manifest_sha256"],
            "release_checksums_sha256": identity["release_checksums_sha256"],
            "release_version": inputs["version"],
            "runtime_sha256": inputs["runtime"]["sha256"],
            "runtime_artifact": inputs["runtime"]["relative"],
            "nse_config_commit": inputs["commit"],
            "nse_archive_sha256": inputs["nse"]["sha256"],
            "machine_env_file": str(machine_env_file),
            "asserted_data_root": str(data_root) if data_root is not None else None,
            "isolation": "machine-env-file-isolated-home-generated-project-run-root-sanitized-plugins",
        })
        save_json(report_file, evidence)

        runtime = extract_runtime(inputs["runtime"]["path"], run / "unpacked/runtime")
        project = extract_nse(inputs["nse"]["path"], run / "unpacked/nse")
        settings = check_nse_profile(project)
        # Preserve the released NSE files unmodified. The selected config
        # env file is generated inside the disposable extracted project.
        state = run / "state"
        run_value = state.as_posix()
        if not re.fullmatch(r"[A-Za-z0-9_@.+/:-]+", run_value):
            raise QualificationError("Qualification run directory contains characters unsupported by the env file")
        qualification_env = project / "envfiles/qualification.env"
        if qualification_env.exists() or qualification_env.is_symlink():
            raise QualificationError("Released NSE project already contains envfiles/qualification.env")
        qualification_env.write_text("# Isolated qualification state; machine data root comes from ~/.cerplot.env\n"
                                     + "CERPLOT_RUN_ROOT=" + run_value + "\n", encoding="utf-8")
        exe = check_registry(runtime)
        evidence["workload"] = settings
        evidence["runtime_executable"] = str(exe.relative_to(runtime))
        save_json(report_file, evidence)

        for part in ("db", "cas", "packages", "sandbox", "logs", "telemetry"):
            (state / part).mkdir(parents=True, exist_ok=True)
        home = run / "home"
        env = isolated_env(home, machine_env_file)

        step("runtime-check", [str(exe), "runtime-check", "--manifest",
             str(runtime / "MANIFEST.toml"), "--expectations",
             str(runtime / "runtime-check-expectations.json")], project, env, args.timeout_smoke)

        inspect_log = step("inspect", [str(exe), "inspect", "--project", str(project),
                        "--profile=local", "--depth=preflight", "--format=json"],
                        project, env, args.timeout_smoke)
        # Inspect writes a single JSON document to stdout. Capture it byte-for-
        # byte; stderr contains independent diagnostic logging, never JSON data.
        inspect_json = run / "evidence/inspect.json"
        shutil.copyfile(inspect_log, inspect_json)
        evidence["preflight"] = check_inspect(inspect_json)
        save_json(report_file, evidence)

        if args.mode == "preflight":
            evidence["status"] = "preflight-passed-not-full-qualification"
            print("NSE PREFLIGHT PASSED (not full qualification)")
            return 0

        assert_port_available(settings["port"])
        log = step("build", [str(exe), "build", "--project", str(project),
                            "--profile=local"], project, env, args.timeout_build)
        # The real CLI returns zero only for a complete BuildCoordinator run;
        # its durable snapshot also binds this attempt to the isolated project.
        evidence["snapshot"] = check_snapshot(log, project)
        evidence["outputs"] = check_results(state)
        evidence["status"] = "passed"
        print(f"QUALIFIED RUNTIME NSE: {inputs['version']} "
              f"runtime_sha256={inputs['runtime']['sha256']}")
        return 0
    except Exception as err:
        # Preserve an explicit failed report even for unexpected platform/SQLite
        # errors. A runner implementation exception must never qualify a product.
        evidence["status"] = "failed"
        evidence["error"] = str(err)
        print("RUNTIME NSE QUALIFICATION FAILED: " + str(err), file=sys.stderr)
        return 1
    finally:
        evidence["completed_utc"] = datetime.now(timezone.utc).isoformat()
        save_json(report_file, evidence)
        print("Evidence: " + str(report_file))
        print("Working directory: " + str(run))


if __name__ == "__main__":
    sys.exit(main())
