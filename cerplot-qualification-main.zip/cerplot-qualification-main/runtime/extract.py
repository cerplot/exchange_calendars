"""Bounded, traversal-safe extraction of downloaded Linux Runtime and NSE source."""
from __future__ import annotations

import os
import stat
import tarfile
import zipfile
from pathlib import Path, PurePosixPath

from bundle import QualificationError

MAX_EXPANDED_BYTES = 12 * 1024**3
MAX_MEMBERS = 100_000


def _parts(name: str) -> tuple[str, ...]:
    if not name or "\\" in name or name.startswith("/"):
        raise QualificationError("Unsafe archive member name: " + repr(name))
    parts = PurePosixPath(name).parts
    if not parts or any(p in {"", ".", ".."} for p in parts):
        raise QualificationError("Archive traversal: " + repr(name))
    return parts


def _root_containment(root: Path, path: Path) -> None:
    if not path.resolve().is_relative_to(root.resolve()):
        raise QualificationError("Archive member escapes destination: " + str(path))


def _safe_parent(root: Path, target: Path) -> None:
    """Reject any member whose parent would be traversed through a symlink."""
    if not target.is_relative_to(root):
        raise QualificationError("Archive member outside destination: " + str(target))
    current = root
    for part in target.relative_to(root).parts[:-1]:
        current = current / part
        if current.is_symlink() or (current.exists() and not current.is_dir()):
            raise QualificationError("Runtime archive uses an unsafe member parent: " + str(current))
    _root_containment(root, target.parent)


def extract_runtime(archive: Path, destination: Path) -> Path:
    """Extract without ever writing through archive links; validate whole link graph.

    Ordinary files/directories are written first, then regular-file hard links
    (possibly forward-referenced), then all symlinks. Every symlink is checked
    against its *final* target only once the complete chain exists. No archive
    writes are performed after a symlink has been created.
    """
    destination.mkdir(mode=0o700, parents=True, exist_ok=False)
    seen: set[tuple[str, ...]] = set()
    hard_links: list[tuple[Path, tuple[str, ...]]] = []
    symbolic_links: list[tuple[Path, str]] = []
    expanded = 0
    with tarfile.open(archive, "r:gz") as tf:
        members = tf.getmembers()
        if len(members) > MAX_MEMBERS:
            raise QualificationError("Runtime tar has too many members")
        for member in members:
            normalized_name = member.name.removeprefix("./").rstrip("/")
            if normalized_name in {"", "."} and member.isdir():
                continue  # CPack's harmless root directory marker
            parts = _parts(normalized_name)
            if parts in seen and not member.isdir():
                raise QualificationError("Duplicate runtime archive member: " + member.name)
            seen.add(parts)
            expanded += max(0, member.size)
            if expanded > MAX_EXPANDED_BYTES:
                raise QualificationError("Runtime archive exceeds extraction budget")
            target = destination.joinpath(*parts)
            _safe_parent(destination, target)
            if member.isdir():
                if target.is_symlink() or (target.exists() and not target.is_dir()):
                    raise QualificationError("Conflicting Runtime directory: " + member.name)
                target.mkdir(parents=True, exist_ok=True)
                continue
            if not (member.isfile() or member.issym() or member.islnk()):
                raise QualificationError("Unsupported Runtime archive member type: " + member.name)
            target.parent.mkdir(parents=True, exist_ok=True)
            if member.isfile():
                if target.exists() or target.is_symlink():
                    raise QualificationError("Duplicate/conflicting Runtime file: " + member.name)
                source = tf.extractfile(member)
                if source is None:
                    raise QualificationError("Cannot read Runtime archive member " + member.name)
                with source, target.open("xb") as out:
                    remaining = member.size
                    while remaining:
                        block = source.read(min(1024 * 1024, remaining))
                        if not block:
                            raise QualificationError("Truncated Runtime tar member: " + member.name)
                        out.write(block)
                        remaining -= len(block)
                target.chmod(0o755 if member.mode & 0o111 else 0o644)
            else:
                link = member.linkname
                if not link or "\\" in link or link.startswith("/"):
                    raise QualificationError("Unsafe Runtime archive link")
                if member.issym():
                    symbolic_links.append((target, link))
                else:
                    hard_links.append((target, _parts(link)))

    # A hard link only names a regular file inside the destination. Support
    # links-to-hard-links and forward references, but never a symlink source.
    pending = hard_links
    while pending:
        remaining = []
        progressed = False
        for target, parts in pending:
            source = destination.joinpath(*parts)
            _safe_parent(destination, source)
            _safe_parent(destination, target)
            if source.is_symlink():
                raise QualificationError("Hard link points to a symlink: " + str(source))
            if not source.is_file():
                remaining.append((target, parts))
                continue
            if target.exists() or target.is_symlink():
                raise QualificationError("Conflicting Runtime hard link: " + str(target))
            os.link(source, target, follow_symlinks=False)
            progressed = True
        if not progressed:
            raise QualificationError("Broken or cyclic Runtime hard links")
        pending = remaining

    # Creating a symlink itself is safe; there are no later file writes. Reject
    # symbolic-link parents even if those parents are from the same archive.
    for target, link in symbolic_links:
        _safe_parent(destination, target)
        if target.exists() or target.is_symlink():
            raise QualificationError("Conflicting Runtime symlink: " + str(target))
        target.symlink_to(link)

    # Validate full chains after all symbolic links have been created. The
    # strict resolve rejects dangling links; RuntimeError rejects cycles.
    root = destination.resolve(strict=True)
    for target, _ in symbolic_links:
        try:
            actual = target.resolve(strict=True)
        except (OSError, RuntimeError) as exc:
            raise QualificationError("Broken or cyclic Runtime symlink: " + str(target)) from exc
        if not actual.is_relative_to(root) or not actual.is_file():
            raise QualificationError("Runtime symlink escapes or is not a regular file: " + str(target))

    # CPack may place one top-level product folder above the Runtime layout.
    roots = [destination]
    if len(list(destination.iterdir())) == 1:
        only = next(destination.iterdir())
        if only.is_dir() and not only.is_symlink():
            roots.append(only)
    valid = [p for p in roots if (p / "runtime-registry.json").is_file()
             and (p / "MANIFEST.toml").is_file()]
    if len(valid) != 1:
        raise QualificationError("Runtime archive must contain exactly one product layout")
    return valid[0]


def extract_nse(archive: Path, destination: Path) -> Path:
    destination.mkdir(mode=0o700, parents=True, exist_ok=False)
    total = 0
    with zipfile.ZipFile(archive) as zf:
        infos = zf.infolist()
        if len(infos) > MAX_MEMBERS:
            raise QualificationError("NSE archive has too many members")
        seen = set()
        for info in infos:
            parts = _parts(info.filename.rstrip("/"))
            if parts in seen and not info.is_dir():
                raise QualificationError("Duplicate NSE source path")
            seen.add(parts)
            if parts[0] != "config-nse":
                raise QualificationError("Expected Git-exported config-nse/ prefix")
            if stat.S_IFMT(info.external_attr >> 16) == stat.S_IFLNK:
                raise QualificationError("NSE source ZIP contains a symlink")
            total += info.file_size
            if total > 200 * 1024**2:
                raise QualificationError("NSE configuration ZIP unexpectedly large")
            target = destination.joinpath(*parts)
            target.parent.mkdir(parents=True, exist_ok=True)
            if info.is_dir():
                target.mkdir(parents=True, exist_ok=True)
            else:
                with zf.open(info) as source, target.open("xb") as out:
                    while block := source.read(1024 * 1024):
                        out.write(block)
    project = destination / "config-nse"
    if not (project / "CerPlot.toml").is_file():
        raise QualificationError("config-nse archive lacks CerPlot.toml")
    return project
