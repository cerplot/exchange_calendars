"""Select exact Runtime and config-nse artifacts from an official CerPlot bundle."""
from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path


class QualificationError(RuntimeError):
    pass


SHA256 = re.compile(r"[0-9a-f]{64}\Z")
COMMIT = re.compile(r"[0-9a-f]{40}\Z")
VERSION = re.compile(r"v[0-9]+\.[0-9]+\.[0-9]+\Z")


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def manifest(bundle: Path) -> dict[str, str]:
    sums = bundle / "SHA256SUMS"
    if not sums.is_file() or sums.is_symlink():
        raise QualificationError("SHA256SUMS is missing or is a symlink")
    result: dict[str, str] = {}
    for line in sums.read_text(encoding="utf-8").splitlines():
        match = re.fullmatch(r"([0-9a-f]{64})  (\*?)([^\r\n]+)", line)
        if not match:
            raise QualificationError("Malformed SHA256SUMS record")
        digest, _, path = match.groups()
        if path in result:
            raise QualificationError("Duplicate checksum record: " + path)
        result[path] = digest
    return result


def select(bundle: Path) -> dict:
    """Only selected files must be downloaded. Dev SDK is intentionally optional."""
    bundle = bundle.resolve(strict=True)
    if not bundle.is_dir():
        raise QualificationError("--bundle is not a directory")
    release_file = bundle / "RELEASE.json"
    if not release_file.is_file() or release_file.is_symlink():
        raise QualificationError("RELEASE.json is missing or is a symlink")
    release = json.loads(release_file.read_text(encoding="utf-8"))
    if not isinstance(release, dict) or not VERSION.fullmatch(str(release.get("version", ""))):
        raise QualificationError("Invalid RELEASE.json version")
    entries = release.get("artifacts")
    sources = release.get("source_repositories")
    if not isinstance(entries, list) or not isinstance(sources, dict):
        raise QualificationError("Release artifact or source inventory is missing")
    nse = sources.get("config-nse")
    if not isinstance(nse, dict) or nse.get("branch") != "main" or not COMMIT.fullmatch(str(nse.get("commit", ""))):
        raise QualificationError("Release lacks valid config-nse main revision")
    commit = nse["commit"]
    sums = manifest(bundle)
    selected = {}
    for kind, pattern in {
        "runtime": re.compile(r"runtime/cerplot-[^/]+-linux-x86_64-Release\.tar\.gz\Z"),
        "nse": re.compile(r"sources/config-nse-" + re.escape(commit[:12]) + r"\.zip\Z"),
    }.items():
        candidates = [item for item in entries if isinstance(item, dict)
                      and isinstance(item.get("path"), str) and pattern.fullmatch(item["path"])]
        if len(candidates) != 1:
            raise QualificationError(f"Expected exactly one {kind} entry in RELEASE.json")
        item = candidates[0]
        relative = item["path"]
        expected = item.get("sha256")
        if not isinstance(expected, str) or not SHA256.fullmatch(expected):
            raise QualificationError("Invalid release checksum for " + relative)
        candidates_paths = [bundle / relative, bundle / "artifacts" / relative]
        located = [p for p in candidates_paths if p.exists() or p.is_symlink()]
        if len(located) != 1:
            raise QualificationError("Expected exactly one downloaded copy of " + relative)
        path = located[0]
        if path.is_symlink() or not path.is_file() or not path.resolve().is_relative_to(bundle):
            raise QualificationError("Unsafe artifact path: " + relative)
        if item.get("bytes") != path.stat().st_size:
            raise QualificationError("Artifact size mismatch: " + relative)
        checksum_key = path.relative_to(bundle).as_posix()
        if sums.get(checksum_key) != expected or sha256_file(path) != expected:
            raise QualificationError("Artifact SHA256 mismatch: " + relative)
        selected[kind] = {"path": path, "relative": relative,
                          "sha256": expected, "bytes": item["bytes"]}
    return {"version": release["version"], "commit": commit, **selected}
