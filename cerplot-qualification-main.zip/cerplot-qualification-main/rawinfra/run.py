#!/usr/bin/env python3
"""Qualify Capture + Live SDKs by building their released RawInfra consumers.

Compilation and linking are the only execution gates. Neither adapter CTests
nor production drivers are run. Inputs come from one verified customer bundle.
"""
from __future__ import annotations

import argparse
import json
import os
import platform
import re
import shutil
import subprocess
import tarfile
import zipfile
import sys
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4

# Direct invocation (python3 rawinfra/run.py) must work from any CWD.
REPOSITORY_ROOT = Path(__file__).resolve().parents[1]
if str(REPOSITORY_ROOT) not in sys.path:
    sys.path.insert(0, str(REPOSITORY_ROOT))
from common.artifacts import BundleError, sha256_file, release_identity
from common.environment import prepare_isolation, run_logged
from common.reporting import Report
from rawinfra.archive_extract import extract_rawinfra_zip, extract_sdk_tgz
from rawinfra.market_identity import require_same_market
from rawinfra.release_native import select_rawinfra_artifacts

RUNNER_REVISION = "rawinfra-consumer-v2"


class QualificationError(RuntimeError):
    pass


def _resolve_command(value: str) -> Path:
    candidate = shutil.which(value)
    if candidate is None:
        raise QualificationError(f"required tool unavailable: {value}")
    resolved = Path(candidate).resolve(strict=True)
    if not resolved.is_file():
        raise QualificationError(f"invalid tool executable: {candidate}")
    return resolved


def _version_output(argv: list[str]) -> str:
    result = subprocess.run(argv, capture_output=True, text=True, timeout=20,
                            check=False)
    if result.returncode != 0:
        raise QualificationError(f"tool version query failed: {argv[0]}")
    return (result.stdout or result.stderr).strip()


def create_run_directory(parent: Path) -> Path:
    parent.mkdir(parents=True, exist_ok=True)
    if parent.is_symlink() or not parent.is_dir():
        raise QualificationError("work directory cannot be a symlink")
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    result = parent / f"rawinfra-{stamp}-{uuid4().hex[:8]}"
    result.mkdir(mode=0o700, exist_ok=False)
    return result


def _package(prefix_root: Path, name: str) -> dict[str, Path | str]:
    """Derive an unambiguous CMake package prefix from the *extracted* kit."""
    configs = [p for p in prefix_root.rglob(f"{name}Config.cmake")
               if p.is_file() and not p.is_symlink()]
    if len(configs) != 1:
        raise QualificationError(
            f"{prefix_root.name}: expected exactly one {name}Config.cmake, found {len(configs)}")
    config = configs[0].resolve(strict=True)
    root = prefix_root.resolve(strict=True)
    if not config.is_relative_to(root):
        raise QualificationError(f"{name} package resolves outside extracted SDK")
    candidates = [a for a in config.parents if a.name in {"lib", "lib64", "share"}
                  and (a / "cmake") in config.parents and a.parent.is_relative_to(root)]
    if len(candidates) != 1:
        raise QualificationError(f"{name} package does not use a supported install prefix layout")
    prefix = candidates[0].parent
    if not prefix.is_relative_to(root):
        raise QualificationError(f"{name} package prefix cannot be isolated")
    return {"prefix": prefix, "config_dir": config.parent,
            "config_file": config, "config_sha256": sha256_file(config)}


def _cache_entries(cache: Path) -> dict[str, str]:
    if not cache.is_file():
        raise QualificationError("CMake did not produce a cache")
    entries: dict[str, str] = {}
    for line in cache.read_text(encoding="utf-8").splitlines():
        if line.startswith(("#", "//")) or "=" not in line or ":" not in line.partition("=")[0]:
            continue
        lhs, _, value = line.partition("=")
        name, _, _kind = lhs.partition(":")
        entries[name] = value
    return entries


def _verify_configuration(cache: Path, *, capture: dict, live: dict,
                          market: dict, cxx: Path) -> None:
    entries = _cache_entries(cache)
    expected = {
        "CerPlotCapture_DIR": str(capture["config_dir"]),
        "CerPlotLive_DIR": str(live["config_dir"]),
        "CerPlotMarket_DIR": str(market["config_dir"]),
        "CMAKE_CXX_COMPILER": str(cxx),
    }
    for key, path in expected.items():
        recorded = entries.get(key)
        if not recorded or Path(recorded).resolve(strict=False) != Path(path).resolve(strict=False):
            raise QualificationError(f"configured {key} does not select the downloaded SDK/toolchain")
    for key in ("CERPLOT_RAWINFRA_BUILD_DATA_DRIVER", "CERPLOT_RAWINFRA_BUILD_LIVE_DRIVER"):
        if entries.get(key, "").upper() not in {"ON", "1", "TRUE", "YES"}:
            raise QualificationError(f"{key} was not enabled in the consumer build")
    for key in ("DATA_DRIVER_BUILD_TESTS", "LIVE_DRIVER_BUILD_TESTS"):
        if entries.get(key, "").upper() not in {"OFF", "0", "FALSE", "NO"}:
            raise QualificationError(f"{key} must be disabled for build-only qualification")
    if entries.get("CMAKE_BUILD_TYPE") != "Release":
        raise QualificationError("consumer CMake build is not Release")


def _command_or_fail(report: Report, name: str, argv: list[str], run_dir: Path,
                     env: dict[str, str], timeout: int) -> None:
    result = run_logged(name=name, argv=argv, cwd=run_dir, env=env,
                        logs=run_dir / "logs", timeout=timeout)
    report.add_step(result)
    if result["status"] != "passed":
        raise QualificationError(f"{name} failed; see {result['log']}")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bundle", type=Path, required=True,
                        help="Customer release directory (download or assembled layout)")
    parser.add_argument("--work-dir", type=Path, required=True,
                        help="Separate parent directory; every run creates a new child")
    parser.add_argument("--external-library-path", type=Path, required=True,
                        help="Installed client ExternalLibraries directory")
    parser.add_argument("--base-raw-library-path", type=Path,
                        help="Override ExternalLibraries/libRawInfra")
    parser.add_argument("--binary-dg-library", type=Path,
                        help="Override ExternalLibraries/binarydg")
    parser.add_argument("--cxx", default="g++", help="Matching GCC C++ compiler (default g++)")
    parser.add_argument("--cmake", default="cmake")
    parser.add_argument("--ninja", default="ninja")
    parser.add_argument("--jobs", type=int, default=4)
    parser.add_argument("--timeout", type=int, default=1800,
                        help="Overall timeout per external command, seconds")
    args = parser.parse_args(argv)
    if args.jobs < 1 or args.timeout < 1:
        parser.error("jobs and timeout must be positive")
    if sys.platform != "linux" or platform.machine().lower() not in {"x86_64", "amd64"}:
        parser.error("RawInfra release SDK qualification currently requires Linux x86_64")
    bundle = args.bundle.expanduser().resolve(strict=False)
    parent = args.work_dir.expanduser().absolute()
    if parent.resolve().is_relative_to(bundle) or bundle.is_relative_to(parent.resolve()):
        parser.error("work directory and release bundle must not overlap")
    try:
        run_dir = create_run_directory(parent)
    except (OSError, QualificationError) as exc:
        print(f"RawInfra qualification setup failed: {exc}", file=sys.stderr)
        return 1
    report = Report(run_dir / "evidence/qualification.json", RUNNER_REVISION,
                    evidence_format="cerplot-rawinfra-consumer-qualification-v1")
    try:
        env = prepare_isolation(run_dir)
        # Remove all host-supplied CMake/compiler/package-search overrides.
        for key in list(env):
            if (key.startswith("CMAKE_") or key.startswith("CerPlot") or
                    key.startswith("LD_") or
                    key in {"CC", "CXX", "CPPFLAGS", "CFLAGS", "CXXFLAGS", "LDFLAGS",
                            "CPATH", "CPLUS_INCLUDE_PATH", "LIBRARY_PATH", "LD_RUN_PATH",
                            "PKG_CONFIG_PATH", "PKG_CONFIG_LIBDIR", "PKG_CONFIG_SYSROOT_DIR"}):
                env.pop(key, None)
        release = select_rawinfra_artifacts(bundle)
        identity = release_identity(bundle)
        if (identity["version"] != release["version"] or
                any(identity["artifacts"].get(item["relative_path"]) != item["sha256"]
                    for item in release["artifacts"].values())):
            raise QualificationError("RawInfra inputs do not match the release inventory")
        external = args.external_library_path.expanduser().resolve(strict=True)
        raw = (args.base_raw_library_path or (external / "libRawInfra")).expanduser().resolve(strict=True)
        dg = (args.binary_dg_library or (external / "binarydg")).expanduser().resolve(strict=True)
        for path in (external, raw, dg):
            if not path.is_dir():
                raise QualificationError(f"native dependency prefix is not a directory: {path}")
        cxx = _resolve_command(args.cxx)
        cmake = _resolve_command(args.cmake)
        ninja = _resolve_command(args.ninja)
        compiler_version = _version_output([str(cxx), "-dumpfullversion", "-dumpversion"])
        cmake_version = _version_output([str(cmake), "--version"]).splitlines()[0]
        if not re.fullmatch(r"[0-9]+(?:\.[0-9]+){1,3}", compiler_version):
            raise QualificationError("selected C++ compiler did not identify a GCC version")
        if int(compiler_version.split(".")[0]) != release["gcc_major"]:
            raise QualificationError(f"release requires GCC {release['gcc_major']}; selected compiler is {compiler_version}")
        cmake_match = re.search(r"cmake version ([0-9]+)\.([0-9]+)", cmake_version)
        if not cmake_match or tuple(map(int, cmake_match.groups())) < (3, 25):
            raise QualificationError("RawInfra consumer needs CMake 3.25 or later")
        report.data.update({
            "release_version": release["version"], "release_gcc": release["toolchain"],
            "release_manifest_sha256": identity["release_manifest_sha256"],
            "release_checksums_sha256": identity["release_checksums_sha256"],
            "compiler": str(cxx), "compiler_version": compiler_version,
            "cmake": str(cmake), "cmake_version": cmake_version,
            "source_commit": release["source_commit"],
            "artifacts": {k: {p: v for p, v in item.items() if p != "path"}
                          for k, item in release["artifacts"].items()},
            "external_dependencies": {"root": str(external), "rawinfra": str(raw),
                                      "binarydg": str(dg)},
            "run_policy": "build-and-link-only;no-driver-execution",
        })
        report.save()
        capture_root = run_dir / "capture_sdk"
        live_root = run_dir / "live_sdk"
        source_root = run_dir / "sources"
        extract_sdk_tgz(release["artifacts"]["capture_sdk"]["path"], capture_root)
        extract_sdk_tgz(release["artifacts"]["live_sdk"]["path"], live_root)
        project = extract_rawinfra_zip(release["artifacts"]["rawinfra_source"]["path"], source_root)
        capture = _package(capture_root, "CerPlotCapture")
        capture_market = _package(capture_root, "CerPlotMarket")
        live = _package(live_root, "CerPlotLive")
        live_market = _package(live_root, "CerPlotMarket")
        common_market_identity = require_same_market(
            capture_market["config_file"], live_market["config_file"])
        report.data["shared_market_identity"] = common_market_identity
        for label, pack in (("capture", capture), ("capture_market", capture_market),
                            ("live", live), ("live_market", live_market)):
            report.data.setdefault("packages", {})[label] = {
                "prefix": str(pack["prefix"]), "config_file": str(pack["config_file"]),
                "config_sha256": pack["config_sha256"]}
        report.save()
        build = run_dir / "build"
        configure = [str(cmake), "-S", str(project), "-B", str(build), "-G", "Ninja",
                     "-DCMAKE_BUILD_TYPE=Release", "-DCMAKE_CXX_COMPILER=" + str(cxx),
                     "-DCMAKE_MAKE_PROGRAM=" + str(ninja),
                     "-DCMAKE_PREFIX_PATH=" + ";".join((str(capture["prefix"]), str(live["prefix"]))),
                     "-DCerPlotCapture_DIR=" + str(capture["config_dir"]),
                     "-DCerPlotLive_DIR=" + str(live["config_dir"]),
                     "-DCerPlotMarket_DIR=" + str(capture_market["config_dir"]),
                     "-DCMAKE_FIND_USE_PACKAGE_REGISTRY=OFF",
                     "-DCMAKE_FIND_USE_SYSTEM_PACKAGE_REGISTRY=OFF",
                     "-DCMAKE_FIND_USE_CMAKE_ENVIRONMENT_PATH=OFF",
                     "-DFETCHCONTENT_FULLY_DISCONNECTED=ON",
                     "-DCERPLOT_RAWINFRA_BUILD_DATA_DRIVER=ON",
                     "-DCERPLOT_RAWINFRA_BUILD_LIVE_DRIVER=ON",
                     "-DDATA_DRIVER_BUILD_TESTS=OFF", "-DLIVE_DRIVER_BUILD_TESTS=OFF",
                     "-DEXTERNAL_LIBRARY_PATH=" + str(external),
                     "-DBASE_RAW_LIBRARY_PATH=" + str(raw),
                     "-DBINARY_DG_LIBRARY=" + str(dg)]
        _command_or_fail(report, "configure", configure, run_dir, env, args.timeout)
        _verify_configuration(build / "CMakeCache.txt", capture=capture, live=live,
                              market=capture_market, cxx=cxx)
        _command_or_fail(report, "build", [str(cmake), "--build", str(build),
                                          "--parallel", str(args.jobs)],
                         run_dir, env, args.timeout)
        binaries: dict[str, dict[str, str | int]] = {}
        for rel in ("src/data-driver/data_capture_exe", "src/live-driver/live_driver"):
            binary = build / rel
            if not binary.is_file() or binary.is_symlink() or not os.access(binary, os.X_OK):
                raise QualificationError(f"missing linked production driver: {rel}")
            size = binary.stat().st_size
            if size <= 0:
                raise QualificationError(f"linked production driver is empty: {rel}")
            binaries[rel] = {"sha256": sha256_file(binary), "bytes": size}
        report.data["built_executables"] = binaries
        report.save()
        report.finish(True)
        print(f"QUALIFIED RAWINFRA CONSUMER: {release['version']} source={release['source_commit'][:12]}")
        print(f"Evidence: {report.path}")
        print(f"Run directory: {run_dir}")
        return 0
    except (BundleError, QualificationError, OSError, ValueError, KeyError,
            RuntimeError, UnicodeError, subprocess.TimeoutExpired,
            zipfile.BadZipFile, tarfile.TarError) as exc:
        report.finish(False, str(exc))
        print(f"RAWINFRA CONSUMER QUALIFICATION FAILED: {exc}", file=sys.stderr)
        print(f"Evidence: {report.path}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
