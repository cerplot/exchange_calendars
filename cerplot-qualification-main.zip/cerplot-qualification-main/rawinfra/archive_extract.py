"""Bounded, path-confined extraction of customer SDK TGZ and Git source ZIP.

Use freshly created private output directories only. Never invoke tar/unzip on
uninspected release archives, and never follow archive-created directory links.
"""
from __future__ import annotations

import os
import shutil
import stat
import tarfile
import zipfile
from pathlib import Path

from common.artifacts import BundleError

MAX_MEMBERS = 100_000
MAX_UNCOMPRESSED = 8 * 1024 ** 3
CHUNK = 1024 * 1024


def _parts(raw: str, *, tar: bool = False) -> tuple[str, ...]:
    if tar:
        while raw.startswith("./"):
            raw = raw[2:]
    if not raw or raw in {".", "/"}:
        return ()
    if raw.startswith("/") or "\\" in raw or "\x00" in raw:
        raise BundleError(f"unsafe archive pathname: {raw!r}")
    raw = raw.rstrip("/")
    parts = tuple(raw.split("/"))
    if any(p in {"", ".", ".."} or ":" in p for p in parts):
        raise BundleError(f"unsafe archive pathname: {raw!r}")
    return parts


def _must_be_fresh(directory: Path) -> None:
    if directory.exists() or directory.is_symlink():
        raise BundleError(f"extraction destination already exists: {directory}")
    directory.mkdir(mode=0o700, parents=True)


def _create_parents(root: Path, member: Path) -> None:
    parent = member.parent
    while parent != root:
        if parent.is_symlink():
            raise BundleError(f"archive would write through a symlink: {parent}")
        if parent.exists() and not parent.is_dir():
            raise BundleError(f"archive parent is not a directory: {parent}")
        parent = parent.parent
    member.parent.mkdir(mode=0o700, parents=True, exist_ok=True)


def _copy_bounded(source, target, expected: int) -> None:
    copied = 0
    with target.open("xb") as out:
        while True:
            part = source.read(min(CHUNK, expected - copied + 1))
            if not part:
                break
            copied += len(part)
            if copied > expected:
                raise BundleError(f"archive member exceeds declared size: {target.name}")
            out.write(part)
    if copied != expected:
        raise BundleError(f"archive member has wrong decompressed size: {target.name}")


def extract_sdk_tgz(archive: Path, destination: Path) -> None:
    """Permit confined relative SONAME links but not escaping/special entries."""
    _must_be_fresh(destination)
    root = destination.resolve(strict=True)
    seen: set[tuple[str, ...]] = set()
    directories: list[Path] = []
    symlinks: list[tuple[Path, str]] = []
    hardlinks: list[tuple[Path, tuple[str, ...]]] = []
    total = 0
    with tarfile.open(archive, "r:gz") as stream:
        for index, member in enumerate(stream):
            if index >= MAX_MEMBERS:
                raise BundleError("SDK archive has too many members")
            parts = _parts(member.name, tar=True)
            if not parts:
                if not member.isdir():
                    raise BundleError("non-directory archive root entry")
                continue
            if parts in seen:
                raise BundleError(f"duplicate SDK archive member: {member.name}")
            seen.add(parts)
            output = root.joinpath(*parts)
            _create_parents(root, output)
            if member.isdir():
                if output.is_symlink() or (output.exists() and not output.is_dir()):
                    raise BundleError("SDK directory conflicts with a file")
                output.mkdir(exist_ok=True)
                directories.append(output)
            elif member.isfile():
                total += member.size
                if member.size < 0 or total > MAX_UNCOMPRESSED:
                    raise BundleError("SDK archive exceeds decompression limit")
                fd = stream.extractfile(member)
                if fd is None:
                    raise BundleError("SDK regular file has no data")
                with fd:
                    _copy_bounded(fd, output, member.size)
                output.chmod(member.mode & 0o777)
            elif member.issym():
                if output.exists() or output.is_symlink():
                    raise BundleError("duplicate SDK symlink destination")
                symlinks.append((output, member.linkname))
            elif member.islnk():
                if output.exists() or output.is_symlink():
                    raise BundleError("duplicate SDK hardlink destination")
                hardlinks.append((output, _parts(member.linkname, tar=True)))
            else:
                raise BundleError(f"unsupported SDK archive entry type: {member.name}")
    # Hardlink targets are archive-root-relative. Support links to earlier files.
    pending = hardlinks
    while pending:
        next_pending = []
        made = 0
        for output, parts in pending:
            source = root.joinpath(*parts)
            if source.is_file() and not source.is_symlink():
                os.link(source, output)
                made += 1
            elif not source.exists():
                next_pending.append((output, parts))
            else:
                raise BundleError("SDK hardlink source must be a regular file")
        if not made:
            raise BundleError("SDK hardlink source absent from archive")
        pending = next_pending
    # Defer symlinks until all file writes finish, avoiding link-parent traversal.
    for output, link in symlinks:
        if not link or link.startswith("/") or "\\" in link or "\x00" in link:
            raise BundleError("SDK symlink has an unsafe target")
        candidate = (output.parent / link).resolve(strict=False)
        if not candidate.is_relative_to(root):
            raise BundleError("SDK symlink points outside extracted prefix")
        output.symlink_to(link)
    for output, _ in symlinks:
        # Resolving *after* all symlinks catches indirect escapes and cycles.
        try:
            target = output.resolve(strict=True)
        except (OSError, RuntimeError) as exc:
            raise BundleError(f"SDK symlink is dangling or cyclic: {output}") from exc
        if not target.is_relative_to(root):
            raise BundleError("SDK symlink escapes extracted prefix")
    if not any(root.rglob("CerPlotMarketConfig.cmake")):
        raise BundleError("SDK archive contains no public CerPlotMarket package")


def extract_rawinfra_zip(archive: Path, destination: Path) -> Path:
    """Git archive must be a regular-file tree prefixed cerplot-rawinfra/."""
    _must_be_fresh(destination)
    root = destination.resolve(strict=True)
    seen: set[tuple[str, ...]] = set()
    total = 0
    with zipfile.ZipFile(archive) as stream:
        for index, info in enumerate(stream.infolist()):
            if index >= MAX_MEMBERS:
                raise BundleError("RawInfra ZIP has too many members")
            parts = _parts(info.filename)
            if not parts or parts[0] != "cerplot-rawinfra":
                raise BundleError("RawInfra ZIP must contain only cerplot-rawinfra/ source")
            if parts in seen:
                raise BundleError(f"duplicate RawInfra ZIP entry: {info.filename}")
            seen.add(parts)
            target = root.joinpath(*parts)
            _create_parents(root, target)
            mode = (info.external_attr >> 16) & 0o170000
            if mode not in {0, stat.S_IFREG, stat.S_IFDIR}:
                raise BundleError("RawInfra ZIP contains a link or special file")
            if info.is_dir():
                if mode not in {0, stat.S_IFDIR} or target.is_symlink():
                    raise BundleError("invalid RawInfra ZIP directory entry")
                target.mkdir(exist_ok=True)
            else:
                if mode == stat.S_IFDIR or info.flag_bits & 1:
                    raise BundleError("encrypted or invalid RawInfra ZIP entry")
                total += info.file_size
                if total > MAX_UNCOMPRESSED:
                    raise BundleError("RawInfra ZIP exceeds decompression limit")
                with stream.open(info) as contents:
                    _copy_bounded(contents, target, info.file_size)
                permissions = (info.external_attr >> 16) & 0o777
                target.chmod(permissions or 0o644)
    source = root / "cerplot-rawinfra"
    for required in ("CMakeLists.txt", "src/data-driver/CMakeLists.txt",
                     "src/live-driver/CMakeLists.txt", "src/common/CMakeLists.txt"):
        if not (source / required).is_file():
            raise BundleError(f"released RawInfra source lacks {required}")
    return source
