"""Offline contract tests for customer archive intake and native consumer gate.

A tiny CMake *test fixture* proves runner wiring; it does not simulate or
qualify RawInfra production code. Full acceptance needs the released source.
"""
from __future__ import annotations

import subprocess
import io
import json
import os
import shutil
import stat
import sys
import tarfile
import tempfile
import unittest
import zipfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from rawinfra.archive_extract import extract_rawinfra_zip, extract_sdk_tgz
from common.artifacts import BundleError, sha256_file
from rawinfra.release_native import select_rawinfra_artifacts
from rawinfra.market_identity import require_same_market
from common.reporting import write_json
from rawinfra.run import main as run_rawinfra_main, QualificationError, _verify_configuration

REV = "b" * 40

def installed_gcc_version() -> str:
    compiler = shutil.which("g++")
    if compiler:
        completed = subprocess.run([compiler, "-dumpfullversion", "-dumpversion"],
                                   capture_output=True, text=True, check=False)
        version = completed.stdout.strip()
        if completed.returncode == 0 and version and version[0].isdigit():
            return version
    return "15.2.1"

TEST_GCC_VERSION = installed_gcc_version()
TEST_GCC_MAJOR = TEST_GCC_VERSION.split(".")[0]


FIXTURE_CMAKE = r'''
cmake_minimum_required(VERSION 3.25)
project(remote_fixture LANGUAGES CXX)
find_package(CerPlotCapture CONFIG REQUIRED)
find_package(CerPlotLive CONFIG REQUIRED)
find_package(CerPlotMarket CONFIG REQUIRED)
if(NOT CERPLOT_RAWINFRA_BUILD_DATA_DRIVER OR NOT CERPLOT_RAWINFRA_BUILD_LIVE_DRIVER)
  message(FATAL_ERROR "both driver options must be selected")
endif()
add_executable(data_capture_exe main.cpp)
add_executable(live_driver main.cpp)
set_target_properties(data_capture_exe PROPERTIES
  RUNTIME_OUTPUT_DIRECTORY "${CMAKE_BINARY_DIR}/src/data-driver")
set_target_properties(live_driver PROPERTIES
  RUNTIME_OUTPUT_DIRECTORY "${CMAKE_BINARY_DIR}/src/live-driver")
'''


def add_tar_bytes(out: tarfile.TarFile, filename: str, body: bytes, mode: int = 0o644) -> None:
    info = tarfile.TarInfo(filename)
    info.size = len(body)
    info.mode = mode
    out.addfile(info, io.BytesIO(body))


def sdk_archive(path: Path, kind: str, *, bad_link: bool = False) -> None:
    base = f"test-{kind}/lib/cmake"
    with tarfile.open(path, "w:gz") as stream:
        for pkg in ("CerPlotMarket", "CerPlotCapture" if kind == "capture" else "CerPlotLive"):
            if pkg == "CerPlotMarket":
                cmake_config = b"""set(CerPlotMarket_VERSION "0.1.8")
set(CerPlotMarket_BUILD_ID "stable-fixture")
set(CerPlotMarket_SDK_ABI_VERSION "1")
set(CerPlotMarket_ABI_ID "test-abi")
set(CerPlotMarket_ABI_VCPKG_TRIPLET "x64-linux")
"""
                variant = b"""set(CerPlotMarket_BUILD_VARIANT_ID "test-variant")
set(CerPlotMarket_CONFIGURATION "Release")
"""
                add_tar_bytes(stream, f"{base}/{pkg}/CerPlotMarketBuildVariant.cmake", variant)
            else:
                cmake_config = b"# fake test fixture package\n"
            add_tar_bytes(stream, f"{base}/{pkg}/{pkg}Config.cmake", cmake_config)
        add_tar_bytes(stream, f"test-{kind}/lib/libfixture.so.1", b"fake-soname")
        link = tarfile.TarInfo(f"test-{kind}/lib/libfixture.so")
        link.type = tarfile.SYMTYPE
        link.linkname = "../outside" if bad_link else "libfixture.so.1"
        stream.addfile(link)


def source_archive(path: Path, *, malformed: bool = False) -> None:
    with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED) as stream:
        files = {
            "CMakeLists.txt": FIXTURE_CMAKE,
            "main.cpp": "int main() {return 0;}\n",
            "src/common/CMakeLists.txt": "# fixture\n",
            "src/data-driver/CMakeLists.txt": "# fixture\n",
            "src/live-driver/CMakeLists.txt": "# fixture\n",
        }
        for name, content in files.items():
            filename = "../escape.cpp" if malformed and name == "main.cpp" else f"cerplot-rawinfra/{name}"
            stream.writestr(filename, content)


def create_bundle(root: Path, *, bad_capture: bool = False,
                  corrupt: bool = False, assembled: bool = False) -> Path:
    prefix = root / "artifacts" if assembled else root
    capture_rel = "capture_sdk/cerplot-capture-sdk-0.1.8-linux-x86_64-Release.tar.gz"
    live_rel = "live_sdk/cerplot-live-sdk-0.1.8-linux-x86_64-Release.tar.gz"
    raw_rel = f"sources/cerplot-rawinfra-{REV[:12]}.zip"
    entries = []
    manifest = []
    for relative, kind in ((capture_rel, "capture"), (live_rel, "live"), (raw_rel, "source")):
        path = prefix / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        if kind == "source":
            source_archive(path)
        else:
            sdk_archive(path, kind, bad_link=bad_capture and kind == "capture")
        sha = sha256_file(path)
        entries.append({"path": relative, "sha256": sha, "bytes": path.stat().st_size,
                        "toolchain": "source" if kind == "source" else "gcc" + TEST_GCC_MAJOR})
        manifest.append(f"{sha}  {path.relative_to(root).as_posix()}\n")
    write_json(root / "RELEASE.json", {
        "version": "v0.1.8", "format": "cerplot-rocky-single-toolchain-release-v2",
        "toolchain": {"name": "gcc" + TEST_GCC_MAJOR, "gcc_version": TEST_GCC_VERSION},
        "source_repositories": {"cerplot-rawinfra": {
            "repository": "git@github.com:cerplot/cerplot-rawinfra.git",
            "branch": "main", "commit": REV}},
        "artifacts": entries,
    })
    (root / "SHA256SUMS").write_text("".join(manifest), encoding="utf-8")
    if corrupt:
        with (prefix / capture_rel).open("ab") as stream:
            stream.write(b"bad")
    return root


class NativeReleaseSelectionTests(unittest.TestCase):
    def test_selects_downloaded_and_assembled_layouts(self):
        for assembled in (False, True):
            with self.subTest(assembled=assembled), tempfile.TemporaryDirectory() as td:
                root = create_bundle(Path(td), assembled=assembled)
                selected = select_rawinfra_artifacts(root)
                self.assertEqual(selected["source_commit"], REV)
                self.assertEqual(set(selected["artifacts"]),
                                 {"capture_sdk", "live_sdk", "rawinfra_source"})

    def test_tampering_fails(self):
        with tempfile.TemporaryDirectory() as td:
            root = create_bundle(Path(td), corrupt=True)
            with self.assertRaises(BundleError):
                select_rawinfra_artifacts(root)

    def test_mismatched_source_provenance_fails(self):
        with tempfile.TemporaryDirectory() as td:
            root = create_bundle(Path(td))
            release = json.loads((root / "RELEASE.json").read_text())
            release["source_repositories"]["cerplot-rawinfra"]["commit"] = "0" * 40
            write_json(root / "RELEASE.json", release)
            with self.assertRaises(BundleError):
                select_rawinfra_artifacts(root)

    def test_market_identity_mismatch_fails(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            cap = root / "capture.tar.gz"
            live = root / "live.tar.gz"
            sdk_archive(cap, "capture")
            sdk_archive(live, "live")
            extract_sdk_tgz(cap, root / "capture")
            extract_sdk_tgz(live, root / "live")
            a = root / "capture/test-capture/lib/cmake/CerPlotMarket/CerPlotMarketConfig.cmake"
            b = root / "live/test-live/lib/cmake/CerPlotMarket/CerPlotMarketConfig.cmake"
            self.assertEqual(require_same_market(a, b)["ABI_ID"], "test-abi")
            b.write_text(b.read_text().replace("test-abi", "different-abi"))
            with self.assertRaises(BundleError):
                require_same_market(a, b)

    def test_missing_sdk_fails(self):
        with tempfile.TemporaryDirectory() as td:
            root = create_bundle(Path(td))
            next((root / "live_sdk").iterdir()).unlink()
            with self.assertRaises(BundleError):
                select_rawinfra_artifacts(root)

    def test_linked_sdk_soname_is_preserved(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            archive = root / "kit.tar.gz"
            sdk_archive(archive, "capture")
            extract_sdk_tgz(archive, root / "stage")
            link = root / "stage/test-capture/lib/libfixture.so"
            self.assertTrue(link.is_symlink())
            self.assertEqual(link.resolve().read_bytes(), b"fake-soname")

    def test_escaping_sdk_symlink_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            archive = root / "kit.tar.gz"
            sdk_archive(archive, "capture", bad_link=True)
            with self.assertRaises(BundleError):
                extract_sdk_tgz(archive, root / "stage")

    def test_sdk_dotdot_member_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            archive = root / "kit.tar.gz"
            with tarfile.open(archive, "w:gz") as stream:
                add_tar_bytes(stream, "../escaped", b"bad")
            with self.assertRaises(BundleError):
                extract_sdk_tgz(archive, root / "stage")
            self.assertFalse((root / "escaped").exists())

    def test_rawinfra_source_symlink_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            archive = root / "source.zip"
            with zipfile.ZipFile(archive, "w") as out:
                info = zipfile.ZipInfo("cerplot-rawinfra/CMakeLists.txt")
                info.create_system = 3
                info.external_attr = (stat.S_IFLNK | 0o777) << 16
                out.writestr(info, "../../etc/passwd")
            with self.assertRaises(BundleError):
                extract_rawinfra_zip(archive, root / "stage")

    def test_rawinfra_zip_traversal_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            archive = root / "source.zip"
            source_archive(archive, malformed=True)
            with self.assertRaises(BundleError):
                extract_rawinfra_zip(archive, root / "stage")
            self.assertFalse((root / "escape.cpp").exists())

    def test_configuration_rejects_enabled_tests(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            cache = root / "CMakeCache.txt"
            cache.write_text("""CerPlotCapture_DIR:PATH=/sdk/capture
CerPlotLive_DIR:PATH=/sdk/live
CerPlotMarket_DIR:PATH=/sdk/market
CMAKE_CXX_COMPILER:FILEPATH=/usr/bin/g++
CMAKE_BUILD_TYPE:STRING=Release
CERPLOT_RAWINFRA_BUILD_DATA_DRIVER:BOOL=ON
CERPLOT_RAWINFRA_BUILD_LIVE_DRIVER:BOOL=ON
DATA_DRIVER_BUILD_TESTS:BOOL=ON
LIVE_DRIVER_BUILD_TESTS:BOOL=OFF
""", encoding="utf-8")
            with self.assertRaisesRegex(QualificationError, "DATA_DRIVER_BUILD_TESTS must be disabled"):
                _verify_configuration(cache, capture={"config_dir": Path("/sdk/capture")},
                                      live={"config_dir": Path("/sdk/live")},
                                      market={"config_dir": Path("/sdk/market")},
                                      cxx=Path("/usr/bin/g++"))


@unittest.skipUnless(sys.platform == "linux" and shutil.which("cmake")
                     and shutil.which("ninja") and shutil.which("g++")
                     and os.environ.get("CERPLOT_DEVTEST_NO_COMPILE") != "1",
                     "native contract fixture needs Linux CMake, Ninja and GCC")
class NativeRunnerIntegrationTests(unittest.TestCase):
    def test_two_sdk_build_only_and_no_driver_execution(self):
        version = TEST_GCC_VERSION
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            bundle = root / "bundle"
            bundle.mkdir()
            create_bundle(bundle)
            external = root / "ExternalLibraries"
            (external / "libRawInfra").mkdir(parents=True)
            (external / "binarydg").mkdir()
            work = root / "runs"
            result = run_rawinfra_main([
                "--bundle", str(bundle), "--work-dir", str(work),
                "--external-library-path", str(external),
                "--cxx", shutil.which("g++") or "g++", "--jobs", "2",
                "--timeout", "180",
            ])
            runs = list(work.glob("rawinfra-*"))
            self.assertEqual(len(runs), 1)
            report = json.loads((runs[0] / "evidence/qualification.json").read_text())
            if result != 0:
                logs = {p.name: p.read_text()[-8000:] for p in (runs[0] / "logs").glob("*.log")}
                self.fail(f"synthetic RawInfra gate failed: {report}\n{logs}")
            self.assertEqual(report["status"], "passed")
            self.assertEqual([step["name"] for step in report["steps"]],
                             ["configure", "build"])
            self.assertEqual(report["run_policy"], "build-and-link-only;no-driver-execution")
            self.assertEqual(len(report["built_executables"]), 2)
            self.assertNotIn("tests", report)
            self.assertTrue(all(item["bytes"] > 0 for item in report["built_executables"].values()))
            self.assertEqual(report["compiler_version"], version)
            from common.artifacts import release_identity
            identity = release_identity(bundle)
            self.assertEqual(report["release_manifest_sha256"], identity["release_manifest_sha256"])
            self.assertEqual(report["release_checksums_sha256"], identity["release_checksums_sha256"])

    def test_build_only_does_not_require_ctest_installation(self):
        # Tests are disabled in the generated CMake consumer. The runner must
        # never invoke CTest or inspect adapter-test result names.
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            bundle = root / "bundle"
            bundle.mkdir()
            create_bundle(bundle)
            external = root / "ExternalLibraries"
            (external / "libRawInfra").mkdir(parents=True)
            (external / "binarydg").mkdir()
            work = root / "runs"
            result = run_rawinfra_main([
                "--bundle", str(bundle), "--work-dir", str(work),
                "--external-library-path", str(external), "--timeout", "180",
            ])
            self.assertEqual(result, 0)
            run = next(work.glob("rawinfra-*"))
            report = json.loads((run / "evidence/qualification.json").read_text())
            self.assertEqual(report["status"], "passed")
            self.assertEqual(set(p.name for p in (run / "logs").glob("*.log")),
                             {"configure.log", "build.log"})
            cache = (run / "build/CMakeCache.txt").read_text()
            self.assertIn("DATA_DRIVER_BUILD_TESTS:UNINITIALIZED=OFF", cache)
            self.assertIn("LIVE_DRIVER_BUILD_TESTS:UNINITIALIZED=OFF", cache)


if __name__ == "__main__":
    unittest.main()
