"""Verify the three *published* RawInfra consumer inputs; no producer checkout.

RELEASE.json and public SHA256SUMS originate from the same customer download.
They establish consistency, not independent release authenticity/signatures.
"""
from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

from common.artifacts import BundleError, _checksums, sha256_file

SHA256 = re.compile(r"[0-9a-f]{64}\Z")
COMMIT = re.compile(r"[0-9a-f]{40}\Z")
VERSION = re.compile(r"v[0-9]+\.[0-9]+\.[0-9]+(?:-[0-9A-Za-z][0-9A-Za-z.-]*)?\Z")
GCC_NAME = re.compile(r"gcc([0-9]+)\Z")
SOURCE_REPO = "git@github.com:cerplot/cerplot-rawinfra.git"


def _one_artifact(entries: list[Any], parent: str, filename: str) -> dict[str, Any]:
    matches = [e for e in entries if isinstance(e, dict)
               and isinstance(e.get("path"), str)
               and e["path"].startswith(parent + "/")]
    if len(matches) != 1 or matches[0]["path"] != f"{parent}/{filename}":
        raise BundleError(f"expected exactly one {parent} artifact named {filename}")
    return matches[0]


def select_rawinfra_artifacts(bundle: Path) -> dict[str, Any]:
    """Require the Capture SDK, Live SDK and source ZIP in the same release.

    Both the downloaded and release-assembler layouts are supported. Other
    release artifacts may be absent from a *selected* customer download.
    """
    bundle = bundle.expanduser().resolve(strict=True)
    if not bundle.is_dir():
        raise BundleError("release bundle must be a directory")
    metadata = bundle / "RELEASE.json"
    manifest = bundle / "SHA256SUMS"
    if not metadata.is_file() or metadata.is_symlink() or not manifest.is_file() or manifest.is_symlink():
        raise BundleError("release requires regular RELEASE.json and SHA256SUMS files")
    release = json.loads(metadata.read_text(encoding="utf-8"))
    if not isinstance(release, dict):
        raise BundleError("RELEASE.json must contain an object")
    version = release.get("version")
    if not isinstance(version, str) or not VERSION.fullmatch(version):
        raise BundleError("invalid official release version")
    toolchain = release.get("toolchain")
    if not isinstance(toolchain, dict) or not isinstance(toolchain.get("name"), str):
        raise BundleError("release lacks toolchain identity")
    match = GCC_NAME.fullmatch(toolchain["name"])
    if not match or not isinstance(toolchain.get("gcc_version"), str) or not (
            toolchain["gcc_version"].split(".")[0] == match.group(1)):
        raise BundleError("release GCC identity is missing or inconsistent")
    sources = release.get("source_repositories")
    if not isinstance(sources, dict) or not isinstance(sources.get("cerplot-rawinfra"), dict):
        raise BundleError("release does not identify the pinned RawInfra source")
    source_spec = sources["cerplot-rawinfra"]
    commit = source_spec.get("commit")
    if (not isinstance(commit, str) or not COMMIT.fullmatch(commit)
            or source_spec.get("repository") != SOURCE_REPO
            or source_spec.get("branch") != "main"):
        raise BundleError("invalid RawInfra source provenance in RELEASE.json")
    entries = release.get("artifacts")
    if not isinstance(entries, list):
        raise BundleError("release artifacts inventory is missing")
    pairs = {
        "capture_sdk": ("capture_sdk", f"cerplot-capture-sdk-{version[1:]}-linux-x86_64-Release.tar.gz"),
        "live_sdk": ("live_sdk", f"cerplot-live-sdk-{version[1:]}-linux-x86_64-Release.tar.gz"),
        "rawinfra_source": ("sources", f"cerplot-rawinfra-{commit[:12]}.zip"),
    }
    checksums = _checksums(manifest)
    selected: dict[str, dict[str, Any]] = {}
    for label, (section, filename) in pairs.items():
        entry = _one_artifact(entries, section, filename) if section != "sources" else None
        if section == "sources":
            # Other released sources (e.g. config-nse) are expected here.
            exact = f"sources/{filename}"
            matches = [e for e in entries if isinstance(e, dict) and
                       isinstance(e.get("path"), str) and
                       e["path"].startswith("sources/cerplot-rawinfra-")]
            if len(matches) != 1 or matches[0]["path"] != exact:
                raise BundleError("missing or duplicate pinned RawInfra source artifact")
            entry = matches[0]
        assert entry is not None
        rel = entry["path"]
        expected = entry.get("sha256")
        size = entry.get("bytes")
        if (not isinstance(expected, str) or not SHA256.fullmatch(expected)
                or type(size) is not int or size <= 0):
            raise BundleError(f"invalid checksum or byte count for {rel}")
        expected_toolchain = "source" if label == "rawinfra_source" else toolchain["name"]
        if entry.get("toolchain") != expected_toolchain:
            raise BundleError(f"wrong toolchain provenance for {rel}")
        paths = [bundle / rel, bundle / "artifacts" / rel]
        present = [p for p in paths if p.exists() or p.is_symlink()]
        if len(present) != 1:
            raise BundleError(f"expected exactly one downloaded file for {rel}")
        path = present[0]
        if path.is_symlink() or not path.is_file() or not path.resolve(strict=True).is_relative_to(bundle):
            raise BundleError(f"unsafe downloaded artifact: {rel}")
        listed_path = path.relative_to(bundle).as_posix()
        if checksums.get(listed_path) != expected:
            raise BundleError(f"SHA256SUMS disagrees with RELEASE.json for {rel}")
        if path.stat().st_size != size or sha256_file(path) != expected:
            raise BundleError(f"downloaded artifact failed size/SHA-256 verification: {rel}")
        selected[label] = {"path": path, "relative_path": rel,
                           "sha256": expected, "bytes": size}
    return {"version": version, "toolchain": toolchain["name"],
            "gcc_major": int(match.group(1)), "gcc_version": toolchain["gcc_version"],
            "source_commit": commit, "artifacts": selected}
