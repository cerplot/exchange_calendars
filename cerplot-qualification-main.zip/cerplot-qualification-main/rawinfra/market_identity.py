"""Compare the independently packaged Market/DataCore identities across kits.

Each SDK contains its own public CerPlotMarket package. The consumer config
imports one Market target, so an explicit second-kit comparison is necessary.
"""
from __future__ import annotations

import re
from pathlib import Path

from common.artifacts import BundleError

_MARKET_FIELDS = ("VERSION", "BUILD_ID", "SDK_ABI_VERSION", "ABI_ID", "ABI_VCPKG_TRIPLET")
_VARIANT_FIELDS = ("BUILD_VARIANT_ID", "CONFIGURATION")


def _literal_set(file: Path, variable: str) -> str:
    if not file.is_file() or file.is_symlink():
        raise BundleError(f"missing regular Market identity file: {file}")
    text = file.read_text(encoding="utf-8")
    pattern = r'(?m)^\s*set\s*\(\s*' + re.escape(variable) + r'\s+"([^"\r\n]*)"\s*\)'
    matches = re.findall(pattern, text)
    if len(matches) != 1:
        raise BundleError(f"missing or ambiguous Market field {variable} in {file.name}")
    return matches[0]


def market_identity(config: Path) -> dict[str, str]:
    variant_file = config.parent / "CerPlotMarketBuildVariant.cmake"
    identity = {key: _literal_set(config, f"CerPlotMarket_{key}") for key in _MARKET_FIELDS}
    identity.update({key: _literal_set(variant_file, f"CerPlotMarket_{key}")
                     for key in _VARIANT_FIELDS})
    if not all(identity[key] for key in ("VERSION", "BUILD_ID", "SDK_ABI_VERSION",
                                        "ABI_ID", "BUILD_VARIANT_ID", "CONFIGURATION")):
        raise BundleError("Market package contains empty required identity metadata")
    if identity["CONFIGURATION"] != "Release":
        raise BundleError("remote qualification requires Release Market packages")
    return identity


def require_same_market(capture_config: Path, live_config: Path) -> dict[str, str]:
    capture = market_identity(capture_config)
    live = market_identity(live_config)
    different = [key for key in capture if capture[key] != live[key]]
    if different:
        raise BundleError("Capture and Live SDKs have incompatible packaged Market identities: "
                          + ", ".join(different))
    return capture
