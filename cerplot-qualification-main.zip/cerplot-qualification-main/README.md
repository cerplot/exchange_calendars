# CerPlot remote qualification

This repository independently qualifies **downloaded CerPlot release artifacts**. It does not use CerPlot's producer build tree, modify the official release manifest, create Git tags, or publish to S3. Keep the three suites separate: they have different input and machine requirements.

| Suite | Released inputs | Acceptance scope |
|---|---|---|
| `python/` | Repaired manylinux Python wheel | Fresh offline venv, installation, `pip check`, compiled-extension imports |
| `runtime/` | Runtime `.tar.gz` and pinned `config-nse` ZIP | Packaged executable, bundled plugins, NSE preflight, **full local research build**, published snapshot and initial persistent-output checks |
| `rawinfra/` | Capture SDK, Live SDK, pinned `cerplot-rawinfra` ZIP | Public SDK compatibility, both native consumer executables compiled and linked (no CTest or driver execution) |

All suites verify their selected artifacts against the downloaded `RELEASE.json` and `SHA256SUMS`. The evidence records the SHA-256 of **both release-inventory files**, in addition to the checksums of the artifacts actually tested. The combined runner rejects any mismatch in release inventory, artifact hashes, source commits, suite format or completion mode. This is local integrity/consistency checking, **not an independent signature or authenticity guarantee**; download through CerPlot's official verified distribution channel.

## Full qualification (all three suites)

On a Linux x86_64 machine with the official extracted customer download, NSE history, Python 3.11, a matching GCC toolchain, CMake/Ninja, and RawInfra's external native dependencies:

```bash
python3 qualify.py \
  --bundle "$HOME/releases/cerplot-v0.1.9-linux" \
  --work-dir "$HOME/cerplot-qualification-runs" \
  --python /usr/bin/python3.11 \
  --external-library-path "$HOME/ExternalLibraries" \
  --cxx /path/to/gcc-15/bin/g++ \
  --jobs 4 \
  --timeout-build 7200 \
  --timeout-smoke 120 \
  --timeout 1800
```

Before running Runtime/NSE or `--suite all`, configure the remote machine's
`~/.cerplot.env` with `CERPLOT_DATA_ROOT` pointing to its historical capture
directory. `--data-root` is optional: it checks a directory exists but does
not replace the machine's Core configuration. The Runtime runner explicitly
selects the real machine env file while keeping HOME and XDG write locations
isolated; it generates a disposable project-local `CERPLOT_RUN_ROOT` override.
You can explicitly select an alternate file with `--machine-env-file FILE`.

Use the actual GCC executable installed on your remote machine; the RawInfra suite checks its major version against the published release toolchain. If your client dependencies are in different locations, supply `--base-raw-library-path` or `--binary-dg-library`. Neither the runtime executable nor the data/live production drivers are taken from your CerPlot source workspace.

`--suite all` **always** runs **Python, Runtime in `full` mode, and RawInfra**. It reports `QUALIFIED REMOTE RELEASE` only if all three exit successfully and produce recognized, fully passing evidence bound to the **same** `RELEASE.json`, `SHA256SUMS`, and expected artifact hashes. Runtime preflight alone is never sufficient. Any failed, absent, partial or inconsistent child report fails the full release.

Each run creates a new isolated work directory and keeps its evidence, logs and outputs. It does not delete prior runs. Never place `--work-dir` inside the release download or the historical-data directory. The combined command currently needs all three suites' dependencies on one machine; aggregation of independently signed reports from multiple machines is **not** implemented.

### Run suites independently

```bash
python3 python/run.py \
  --bundle "$HOME/releases/cerplot-v0.1.9-linux" \
  --python /usr/bin/python3.11 \
  --work-dir "$HOME/cerplot-qualification-runs"

python3 runtime/run.py \
  --bundle "$HOME/releases/cerplot-v0.1.9-linux" \
  --work-dir "$HOME/cerplot-qualification-runs"

python3 rawinfra/run.py \
  --bundle "$HOME/releases/cerplot-v0.1.9-linux" \
  --external-library-path "$HOME/ExternalLibraries" \
  --cxx /path/to/gcc-15/bin/g++ \
  --work-dir "$HOME/cerplot-qualification-runs"
```

For diagnosis, the top-level command also accepts `--suite python`, `--suite runtime`, or `--suite rawinfra` with the corresponding arguments. A selected suite may pass on its own, but the top-level evidence is marked **not fully qualified**, and it does not print `QUALIFIED REMOTE RELEASE`. The Runtime suite itself also permits `--mode preflight` for debugging, which cannot qualify a release.

## Suite-specific limitations

- **Python:** The existing checks verify native module installation and imports, not every binding's functional semantics. Installation is offline (`--no-index --no-deps`); the Python environment must already contain appropriate wheel tooling.
- **Runtime/NSE:** Validates the shipped NSE `local` profile for **4 assets, 5 fit days and 2 test days**, runs a packaged `runtime-check` and preflight, then executes a full local build. It checks a published run snapshot and nonempty SQLite/CAS state. It does **not** independently prove the exact terminal status of every planned research shard or evaluate model R²; stronger assertions will be based on actual stable Results/Manifest records after a real run. See [runtime/README.md](runtime/README.md).
- **RawInfra:** Compiles and links the actual external Data and Live Drivers against the two extracted, ABI-compatible SDKs. **Neither CTest nor either production driver is executed** and no live order-routing session is started. Proprietary RawInfra dependencies must be installed on the consumer machine. This is not an operational/trading qualification.

The Runtime extractor supports contained ELF symlink chains and contained hard links, including forward references, but rejects traversal, escapes, dangling links, cycles, special file types, and attempts to write through extracted symbolic-link parents. All suites redirect `HOME`, XDG config/cache/data/state paths and scratch state into the fresh run directory, and scrub plugin overrides and relevant development environment variables. The Runtime suite also selects the invoking machine's `~/.cerplot.env` via Core's `CERPLOT_ENV_FILE` and overrides only the temporary research run root through a generated project env file; Python and RawInfra remain fully isolated from machine CerPlot configuration.

## Evidence

The combined runner writes:

```text
qualification-<timestamp>-<random>/
  evidence/qualification.json
  logs/{python,runtime,rawinfra}.log
  python/python-.../evidence/qualification.json
  runtime/runtime-.../evidence/qualification.json
  rawinfra/rawinfra-.../evidence/qualification.json
```

Each child evidence record includes its selected artifact checksum(s) and the hashes of `RELEASE.json` and `SHA256SUMS`. The combined report additionally verifies that every child represents the same release inventory and complete test mode. Large research CAS and build files remain in the qualification workspace, not in the customer release.

**This is independent remote acceptance, not a new stage of the official Rocky build/tag/S3 publication process.** In particular, CerPlot v0.1.8's prior producer-side qualification is unchanged. A genuine remote acceptance result requires executing these suites against the real downloaded v0.1.8 artifacts and client dependencies.

## Development/regression tests

```bash
python3 -m unittest discover -s python/devtests -p 'test_*.py' -v
python3 -m unittest discover -s runtime/devtests -p 'test_*.py' -v
python3 -m unittest discover -s rawinfra/devtests -p 'test_*.py' -v
python3 -m unittest discover -s devtests -p 'test_*.py' -v
```

These use small synthetic releases and mock providers; they verify runner control flow, failure handling, archive safety and report validation. They **do not** replace a real remote release qualification run. The repository itself should be version-controlled independently, and its exact tested Git revision recorded when later integrating remote qualification with the official release lifecycle.
