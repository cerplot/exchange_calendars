"""Shared environment isolation and process supervision for qualification suites."""
from __future__ import annotations

import os
import signal
import shlex
import subprocess
import time
from pathlib import Path
from typing import Any



def sanitized_environment(run_dir: Path) -> dict[str, str]:
    env = os.environ.copy()
    for key in list(env):
        if (key.startswith("CERPLOT_") or key.startswith("VCPKG_") or
                key in {"PYTHONPATH", "PYTHONHOME", "PYTHONSTARTUP", "PYTHONUSERBASE",
                        "LD_LIBRARY_PATH", "LD_PRELOAD", "LD_AUDIT", "DYLD_LIBRARY_PATH",
                        "DYLD_INSERT_LIBRARIES", "VIRTUAL_ENV", "CONDA_PREFIX",
                        "PIP_INDEX_URL", "PIP_EXTRA_INDEX_URL", "PIP_REQUIRE_VIRTUALENV"}):
            env.pop(key, None)
    # Avoid picking up user pip configuration or user-installed Python packages.
    env.update({
        "HOME": str(run_dir / "home"),
        "XDG_CONFIG_HOME": str(run_dir / "config"),
        "XDG_CACHE_HOME": str(run_dir / "cache"),
        "XDG_DATA_HOME": str(run_dir / "data"),
        "XDG_STATE_HOME": str(run_dir / "state"),
        "TMPDIR": str(run_dir / "tmp"),
        "PYTHONNOUSERSITE": "1",
        "PIP_CONFIG_FILE": os.devnull,
        "PIP_NO_INDEX": "1",
        "PIP_NO_CACHE_DIR": "1",
        "PIP_DISABLE_PIP_VERSION_CHECK": "1",
        "PYTHONDONTWRITEBYTECODE": "1",
    })
    return env


def prepare_isolation(run_dir: Path) -> dict[str, str]:
    for name in ("home", "tmp", "config", "cache", "data", "state", "logs", "evidence"):
        (run_dir / name).mkdir(mode=0o700, exist_ok=True)
    return sanitized_environment(run_dir)


def run_logged(*, name: str, argv: list[str], cwd: Path, env: dict[str, str],
               logs: Path, timeout: int) -> dict[str, Any]:
    """Execute without shell interpolation and persist logs even on failure."""
    if timeout < 1:
        raise ValueError("timeout must be positive")
    log_file = logs / f"{name}.log"
    started = time.monotonic()
    returncode: int | None = None
    failure: str | None = None
    with log_file.open("w", encoding="utf-8", errors="backslashreplace") as log:
        log.write("COMMAND: " + shlex.join(argv) + "\n")
        log.write("CWD: " + str(cwd) + "\n\n")
        log.flush()
        process: subprocess.Popen | None = None
        try:
            # A native CMake/Ninja/CTest tree can spawn many descendants.
            # Put POSIX commands in their own process group so a timeout does
            # not leave compilers or adapter tests running after qualification.
            process = subprocess.Popen(argv, cwd=cwd, env=env, stdout=log,
                                       stderr=subprocess.STDOUT,
                                       start_new_session=(os.name == "posix"))
            returncode = process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            failure = f"timed out after {timeout} seconds"
            if process is not None:
                try:
                    if os.name == "posix":
                        os.killpg(process.pid, signal.SIGKILL)
                    else:
                        process.kill()
                except ProcessLookupError:
                    pass  # Already reaped while handling the timeout.
                process.wait()
            log.write("\nERROR: " + failure + "\n")
        except OSError as exc:
            failure = f"process launch failed: {exc}"
            log.write("\nERROR: " + failure + "\n")
    result: dict[str, Any] = {
        "name": name,
        "log": str(log_file.relative_to(cwd)),
        "exit_code": returncode,
        "seconds": round(time.monotonic() - started, 3),
        "status": "passed" if returncode == 0 and failure is None else "failed",
    }
    if failure:
        result["error"] = failure
    return result
