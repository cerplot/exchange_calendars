"""Shared infrastructure for the remote qualification suites."""
