"""Generic release-artifact integrity helpers for non-Python qualification suites."""
from __future__ import annotations

import hashlib
import re
from pathlib import Path


CHECKSUM = re.compile(r"([0-9a-f]{64})  ([^\r\n]+)\Z")


class BundleError(ValueError):
    pass


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as file:
        for chunk in iter(lambda: file.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _checksums(filename: Path) -> dict[str, str]:
    found: dict[str, str] = {}
    for line in filename.read_text(encoding="utf-8").splitlines():
        m = CHECKSUM.fullmatch(line)
        if not m:
            raise BundleError("invalid SHA256SUMS record")
        digest, path = m.groups()
        if path in found:
            raise BundleError("duplicate SHA256SUMS entry: " + path)
        found[path] = digest
    return found



def release_identity(bundle: Path) -> dict:
    """Bind independent suite evidence to one downloaded release inventory.

    The customer may download only selected products, so this validates the
    official inventory and checksum records without requiring every product to
    be present. Each suite remains responsible for hashing the files it uses.
    """
    import json

    release_path = bundle / "RELEASE.json"
    sums_path = bundle / "SHA256SUMS"
    for path in (release_path, sums_path):
        if path.is_symlink() or not path.is_file():
            raise BundleError(f"release identity file missing or symlinked: {path.name}")
    try:
        release = json.loads(release_path.read_text(encoding="utf-8"))
    except (ValueError, UnicodeError) as exc:
        raise BundleError("invalid RELEASE.json") from exc
    if not isinstance(release, dict):
        raise BundleError("RELEASE.json must contain an object")
    version = release.get("version")
    if not isinstance(version, str) or not re.fullmatch(
            r"v[0-9]+\.[0-9]+\.[0-9]+(?:-[0-9A-Za-z][0-9A-Za-z.-]*)?", version):
        raise BundleError("invalid release version")
    entries = release.get("artifacts")
    if not isinstance(entries, list):
        raise BundleError("release artifact inventory is missing")
    artifacts: dict[str, str] = {}
    for item in entries:
        if not isinstance(item, dict):
            raise BundleError("malformed release artifact entry")
        relative, digest = item.get("path"), item.get("sha256")
        if (not isinstance(relative, str) or not relative or relative.startswith("/")
                or "\\" in relative or any(p in {"", ".", ".."} for p in relative.split("/"))
                or not isinstance(digest, str) or not re.fullmatch(r"[0-9a-f]{64}", digest)):
            raise BundleError("unsafe artifact path or checksum in RELEASE.json")
        if relative in artifacts:
            raise BundleError("duplicate release artifact inventory path: " + relative)
        artifacts[relative] = digest
    sums = _checksums(sums_path)
    for relative, expected in artifacts.items():
        choices = (relative, "artifacts/" + relative)
        present = [key for key in choices if key in sums]
        if len(present) > 1:
            raise BundleError("ambiguous checksum paths for " + relative)
        if present and sums[present[0]] != expected:
            raise BundleError("SHA256SUMS disagrees with RELEASE.json for " + relative)
    return {
        "version": version,
        "release_manifest_sha256": sha256_file(release_path),
        "release_checksums_sha256": sha256_file(sums_path),
        "artifacts": artifacts,
        "checksum_entries": sums,
    }
