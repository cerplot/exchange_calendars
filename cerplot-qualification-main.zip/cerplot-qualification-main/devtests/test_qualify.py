"""Combined release acceptance: a zero exit is not sufficient evidence."""
from __future__ import annotations

import hashlib
import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from common.artifacts import release_identity
from common.reporting import write_json
from qualify import main

NSE_COMMIT = "a" * 40
RAWINFRA_COMMIT = "b" * 40
VERSION = "v0.1.8"
ARTIFACT_PATHS = {
    "python": "python/cerplot-0.1.8-cp311-cp311-manylinux_2_27_x86_64.whl",
    "runtime": "runtime/cerplot-0.1.8-linux-x86_64-Release.tar.gz",
    "nse": "sources/config-nse-aaaaaaaaaaaa.zip",
    "capture_sdk": "capture_sdk/cerplot-capture-sdk-0.1.8-linux-x86_64-Release.tar.gz",
    "live_sdk": "live_sdk/cerplot-live-sdk-0.1.8-linux-x86_64-Release.tar.gz",
    "rawinfra_source": "sources/cerplot-rawinfra-bbbbbbbbbbbb.zip",
}


def release_fixture(root: Path) -> dict:
    root.mkdir(parents=True)
    records = []
    sums = []
    for label, name in ARTIFACT_PATHS.items():
        value = ("fake-" + label).encode("ascii")
        sha = hashlib.sha256(value).hexdigest()
        path = root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(value)
        records.append({"path": name, "sha256": sha, "bytes": len(value)})
        sums.append(f"{sha}  {name}\n")
    write_json(root / "RELEASE.json", {
        "version": VERSION,
        "source_repositories": {
            "config-nse": {"commit": NSE_COMMIT},
            "cerplot-rawinfra": {"commit": RAWINFRA_COMMIT},
        },
        "artifacts": records,
    })
    (root / "SHA256SUMS").write_text("".join(sums), encoding="utf-8")
    return release_identity(root)


def child_fixture(name: str, identity: dict) -> dict:
    basic = {
        "status": "passed", "release_version": VERSION,
        "release_manifest_sha256": identity["release_manifest_sha256"],
        "release_checksums_sha256": identity["release_checksums_sha256"],
    }
    if name == "python":
        return {**basic, "format": "cerplot-python-qualification-v1",
                "test_selection": "all", "tests": {"status": "passed", "executed": 2},
                "wheel_path": ARTIFACT_PATHS["python"],
                "wheel_sha256": identity["artifacts"][ARTIFACT_PATHS["python"]]}
    if name == "runtime":
        return {**basic, "format": "cerplot-runtime-nse-qualification-v1", "mode": "full",
                "steps": [{"name": step, "status": "passed"}
                          for step in ("runtime-check", "inspect", "build")],
                "snapshot": {"attempt_id": "one"}, "outputs": {"cas_files": 1},
                "runtime_artifact": ARTIFACT_PATHS["runtime"],
                "runtime_sha256": identity["artifacts"][ARTIFACT_PATHS["runtime"]],
                "nse_config_commit": NSE_COMMIT,
                "nse_archive_sha256": identity["artifacts"][ARTIFACT_PATHS["nse"]]}
    return {**basic, "format": "cerplot-rawinfra-consumer-qualification-v1",
            "run_policy": "build-and-link-only;no-driver-execution",
            "source_commit": RAWINFRA_COMMIT,
            "steps": [{"name": step, "status": "passed"} for step in ("configure", "build")],
            "built_executables": {
                "src/data-driver/data_capture_exe": {"sha256": "a" * 64, "bytes": 256},
                "src/live-driver/live_driver": {"sha256": "b" * 64, "bytes": 512},
            },
            "artifacts": {label: {"relative_path": ARTIFACT_PATHS[label],
                                  "sha256": identity["artifacts"][ARTIFACT_PATHS[label]]}
                          for label in ("capture_sdk", "live_sdk", "rawinfra_source")}}


class CombinedReportTests(unittest.TestCase):
    def _run(self, *, selection: str = "all", mutation=None, missing: str | None = None,
             process_failed: str | None = None, bundle_mutation=None):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            bundle = base / "bundle"
            identity = release_fixture(bundle)
            work = base / "runs"
            data = base / "historical-data"
            data.mkdir()
            machine_file = base / "user-home/.cerplot.env"
            machine_file.parent.mkdir(parents=True)
            machine_file.write_text(f"CERPLOT_DATA_ROOT={data}\n", encoding="utf-8")
            deps = base / "ExternalLibraries"
            deps.mkdir()
            calls, invoked = [], []

            def fake_logged(*, name, argv, cwd, env, logs, timeout):
                calls.append(name)
                invoked.append((name, Path(argv[1]), argv[:], timeout))
                child = next(work.glob("qualification-*")) / name / f"{name}-fixture"
                child.mkdir(parents=True)
                if bundle_mutation:
                    bundle_mutation(name, bundle)
                if name != missing:
                    content = child_fixture(name, identity)
                    if mutation:
                        mutation(name, content)
                    write_json(child / "evidence/qualification.json", content)
                return {"name": name, "log": f"logs/{name}.log",
                        "status": "failed" if name == process_failed else "passed",
                        "exit_code": 1 if name == process_failed else 0, "seconds": 0.01}

            args = ["--bundle", str(bundle), "--work-dir", str(work),
                    "--suite", selection, "--python", sys.executable,
                    "--machine-env-file", str(machine_file),
                    "--data-root", str(data), "--external-library-path", str(deps),
                    "--timeout-build", "31", "--timeout-smoke", "17"]
            with patch("qualify.run_logged", side_effect=fake_logged):
                result = main(args)
            runs = list(work.glob("qualification-*"))
            self.assertEqual(len(runs), 1)
            report = json.loads((runs[0] / "evidence/qualification.json").read_text())
            return result, report, calls, invoked

    def test_full_qualification_requires_three_suites_and_exact_identity(self):
        rc, report, calls, invoked = self._run()
        self.assertEqual(rc, 0)
        self.assertEqual(report["status"], "passed")
        self.assertEqual(calls, ["python", "runtime", "rawinfra"])
        self.assertEqual(set(report["suites"]), set(calls))
        self.assertRegex(report["release_manifest_sha256"], r"^[0-9a-f]{64}$")
        self.assertRegex(report["release_checksums_sha256"], r"^[0-9a-f]{64}$")
        root = Path(__file__).resolve().parents[1]
        for name, entrypoint, argv, deadline in invoked:
            self.assertEqual(entrypoint, root / name / "run.py")
            if name == "runtime":
                self.assertIn("--mode", argv)
                self.assertEqual(argv[argv.index("--mode") + 1], "full")
                self.assertIn("--machine-env-file", argv)
                self.assertIn("--data-root", argv)
                self.assertEqual(argv[argv.index("--timeout-build") + 1], "31")
                self.assertEqual(argv[argv.index("--timeout-smoke") + 1], "17")
                self.assertGreaterEqual(deadline, 31 + 2 * 17)

    def test_runtime_machine_environment_is_passed_even_with_isolated_combined_home(self):
        rc, _, _, invoked = self._run()
        self.assertEqual(rc, 0)
        runtime_argv = next(argv for name, _, argv, _ in invoked if name == 'runtime')
        machine_file = Path(runtime_argv[runtime_argv.index('--machine-env-file') + 1])
        self.assertEqual(machine_file.name, '.cerplot.env')

    def test_rawinfra_build_only_is_required(self):
        rc, report, _calls, invoked = self._run()
        self.assertEqual(rc, 0)
        argv = next(cmd for name, _, cmd, _ in invoked if name == "rawinfra")
        self.assertNotIn("--ctest", argv)
        self.assertNotIn("--test-timeout", argv)

    def test_rawinfra_old_ctest_policy_is_rejected(self):
        def mutation(name, evidence):
            if name == "rawinfra":
                evidence["run_policy"] = "build-and-offline-adapter-tests-only;no-driver-execution"
        rc, report, _calls, _ = self._run(mutation=mutation)
        self.assertEqual(rc, 1)
        self.assertIn("build-and-link-only", report["error"])

    def test_rawinfra_missing_driver_build_evidence_is_rejected(self):
        def mutation(name, evidence):
            if name == "rawinfra":
                evidence["built_executables"].pop("src/live-driver/live_driver")
        rc, report, _calls, _ = self._run(mutation=mutation)
        self.assertEqual(rc, 1)
        self.assertIn("both linked driver executables", report["error"])

    def test_rawinfra_failed_build_step_is_rejected(self):
        def mutation(name, evidence):
            if name == "rawinfra":
                evidence["steps"][1]["status"] = "failed"
        rc, report, _calls, _ = self._run(mutation=mutation)
        self.assertEqual(rc, 1)
        self.assertIn("configure/build step evidence", report["error"])

    def test_single_suites_are_not_release_qualification(self):
        for name in ("python", "runtime", "rawinfra"):
            with self.subTest(name=name):
                rc, report, calls, _ = self._run(selection=name)
                self.assertEqual(rc, 0)
                self.assertEqual(report["status"], "failed")
                self.assertEqual(calls, [name])

    def test_failed_suite_rejected(self):
        rc, report, calls, _ = self._run(process_failed="runtime")
        self.assertEqual(rc, 1)
        self.assertEqual(report["status"], "failed")
        self.assertEqual(calls, ["python", "runtime"])

    def test_missing_child_report_rejected(self):
        rc, report, calls, _ = self._run(missing="runtime")
        self.assertEqual(rc, 1)
        self.assertEqual(report["status"], "failed")
        self.assertEqual(calls, ["python", "runtime"])

    def test_preflight_cannot_qualify(self):
        def mutation(name, evidence):
            if name == "runtime":
                evidence["mode"] = "preflight"
        rc, report, calls, _ = self._run(mutation=mutation)
        self.assertEqual(rc, 1)
        self.assertIn("full mode", report["error"])
        self.assertEqual(calls, ["python", "runtime"])

    def test_runtime_missing_full_build_evidence_rejected(self):
        def mutation(name, evidence):
            if name == "runtime":
                evidence.pop("snapshot")
        rc, report, _, _ = self._run(mutation=mutation)
        self.assertEqual(rc, 1)
        self.assertIn("completion evidence", report["error"])

    def test_release_version_mismatch_rejected(self):
        def mutation(name, evidence):
            if name == "rawinfra":
                evidence["release_version"] = "v0.1.9"
        rc, report, _, _ = self._run(mutation=mutation)
        self.assertEqual(rc, 1)
        self.assertIn("release version", report["error"])

    def test_same_version_different_release_json_rejected(self):
        def mutation(name, evidence):
            if name == "runtime":
                evidence["release_manifest_sha256"] = "0" * 64
        rc, report, _, _ = self._run(mutation=mutation)
        self.assertEqual(rc, 1)
        self.assertIn("release inventory", report["error"])

    def test_same_release_but_wrong_artifact_checksum_rejected(self):
        def mutation(name, evidence):
            if name == "rawinfra":
                evidence["artifacts"]["live_sdk"]["sha256"] = "f" * 64
        rc, report, _, _ = self._run(mutation=mutation)
        self.assertEqual(rc, 1)
        self.assertIn("RELEASE.json artifact inventory", report["error"])

    def test_partial_python_evidence_rejected(self):
        def mutation(name, evidence):
            if name == "python":
                evidence["test_selection"] = "imports"
        rc, report, calls, _ = self._run(mutation=mutation)
        self.assertEqual(rc, 1)
        self.assertEqual(calls, ["python"])
        self.assertIn("all tests", report["error"])

    def test_mismatched_nse_commit_rejected(self):
        def mutation(name, evidence):
            if name == "runtime":
                evidence["nse_config_commit"] = "c" * 40
        rc, report, _, _ = self._run(mutation=mutation)
        self.assertEqual(rc, 1)
        self.assertIn("config-nse source revision", report["error"])

    def test_release_inventory_changed_during_run_rejected(self):
        def bundle_mutation(name, bundle):
            if name == "runtime":
                metadata = json.loads((bundle / "RELEASE.json").read_text())
                metadata["unexpected_change"] = "mid-run"
                write_json(bundle / "RELEASE.json", metadata)
        rc, report, calls, _ = self._run(bundle_mutation=bundle_mutation)
        self.assertEqual(rc, 1)
        self.assertIn("release inventory changed", report["error"])
        self.assertEqual(calls, ["python", "runtime"])

    def test_malformed_release_inventory_rejected_before_children(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            release_fixture(root / "bundle")
            (root / "bundle/RELEASE.json").write_text("not JSON")
            work = root / "work"
            rc = main(["--bundle", str(root / "bundle"), "--work-dir", str(work),
                       "--suite", "python", "--python", sys.executable])
            self.assertEqual(rc, 1)
            report = json.loads(next(work.glob("qualification-*/evidence/qualification.json")).read_text())
            self.assertEqual(report["status"], "failed")


if __name__ == "__main__":
    unittest.main()
