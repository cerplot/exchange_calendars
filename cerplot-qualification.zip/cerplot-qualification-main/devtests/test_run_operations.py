"""Test safe run discovery and explicit retention cleanup."""
from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from common.runs import remember_run, require_safe_work_parent
from clean import candidates, main as clean_main


class RunOperationsTests(unittest.TestCase):
    def test_local_release_scratch_is_the_only_allowed_overlap(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            bundle = base / "release"
            bundle.mkdir()
            require_safe_work_parent(bundle, bundle / ".qualification-work")
            require_safe_work_parent(bundle, bundle / ".qualification-work/python")
            require_safe_work_parent(bundle, base / "detached-work")
            for bad in (bundle, base, bundle / "runtime", bundle / "sources",
                        bundle / ".qualification-work/../runtime"):
                with self.subTest(bad=str(bad)), self.assertRaises(ValueError):
                    require_safe_work_parent(bundle, bad)
            outside = base / "outside"
            outside.mkdir()
            (bundle / ".qualification-work").symlink_to(outside, target_is_directory=True)
            with self.assertRaises(ValueError):
                require_safe_work_parent(bundle, bundle / ".qualification-work/python")

    def test_latest_pointer_is_updated_without_reusing_state(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            first = base / 'runtime-20261017T000000Z-aaaaaaaa'
            second = base / 'runtime-20261017T000001Z-bbbbbbbb'
            first.mkdir(); second.mkdir()
            pointer = remember_run(base, 'runtime', first)
            self.assertEqual(pointer.read_text().strip(), str(first.resolve()))
            remember_run(base, 'runtime', second)
            self.assertEqual(pointer.read_text().strip(), str(second.resolve()))
            self.assertTrue(first.is_dir())

    def test_cleanup_only_completed_old_runs_and_dry_run_default(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            paths = []
            for i in range(4):
                d = root / f'runtime-20261017T00000{i}Z-{i:08x}'
                (d / 'evidence').mkdir(parents=True)
                (d / 'evidence/qualification.json').write_text(json.dumps({
                    'status': 'passed', **({'completed_utc': '2026-10-17T00:00:00Z'} if i != 1 else {})}))
                paths.append(d)
            outsider = root / 'ordinary-data'; outsider.mkdir()
            self.assertEqual(candidates(root, 1), [paths[2], paths[0]])
            self.assertEqual(clean_main(['--work-dir', str(root), '--keep', '1']), 0)
            self.assertTrue(paths[0].exists())
            self.assertEqual(clean_main(['--work-dir', str(root), '--keep', '1', '--apply']), 0)
            self.assertFalse(paths[0].exists())
            self.assertFalse(paths[2].exists())
            self.assertTrue(paths[1].exists())  # Still running / incomplete
            self.assertTrue(paths[-1].exists())  # Most recent
            self.assertTrue(outsider.exists())

    def test_symlink_runs_are_ignored(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            for i in range(3):
                d = root / f'python-20261017T00000{i}Z-{i:08x}'
                (d / 'evidence').mkdir(parents=True)
                (d / 'evidence/qualification.json').write_text('{"status":"passed","completed_utc":"yes"}')
            evil = root / 'python-20261017T000003Z-eeeeeeee'
            evil.symlink_to(root / 'python-20261017T000000Z-00000000', target_is_directory=True)
            self.assertNotIn(evil, candidates(root, 1))


if __name__ == '__main__':
    unittest.main()
