# CerPlot remote qualification

This repository independently qualifies **downloaded CerPlot release artifacts**. It does not use CerPlot's producer build tree, modify the official release manifest, create Git tags, or publish to S3. Keep the three suites separate: they have different input and machine requirements.

| Suite | Released inputs | Acceptance scope |
|---|---|---|
| `python/` | Repaired manylinux Python wheel | Fresh offline venv, installation, `pip check`, compiled-extension imports |
| `runtime/` | Runtime `.tar.gz` and pinned `config-nse` ZIP | Packaged executable, bundled plugins, NSE preflight, **full local research build**, published snapshot and initial persistent-output checks |
| `rawinfra/` | Capture SDK, Live SDK, pinned `cerplot-rawinfra` ZIP | Public SDK compatibility, both native consumer executables compiled and linked (no CTest or driver execution) |

All suites verify their selected artifacts against the downloaded `RELEASE.json` and `SHA256SUMS`. The evidence records the SHA-256 of **both release-inventory files**, in addition to the checksums of the artifacts actually tested. The combined runner rejects any mismatch in release inventory, artifact hashes, source commits, suite format or completion mode. This is local integrity/consistency checking, **not an independent signature or authenticity guarantee**; download through CerPlot's official verified distribution channel.

## Full qualification (all three suites)

For the normal customer release layout, extract the `cerplot-qualification` source ZIP
**inside the downloaded release** (for example, into `qualification/`):

```text
cerplot-v0.1.10-linux/
  RELEASE.json
  SHA256SUMS
  runtime/  python/  capture_sdk/  live_sdk/  sources/
  qualification/cerplot-qualification/qualify.py
```

With Python 3.11 already selected (including an activated virtual environment),
run this from the directory containing `qualify.py`:

```bash
python qualify.py
```

By default this runs `--suite all`, discovers `RELEASE.json` and `SHA256SUMS`
by walking upward from **the runner's own location**, uses the invoking Python
interpreter, and creates fresh test directories under the downloaded release's
`.qualification-work/` directory. It does not overwrite or reuse previous
SQLite/CAS/results. On success only, it atomically writes local `QUALIFIED.json`
at the release root, with the version, release-manifest checksums and evidence
location. The marker is invalidated at the beginning of each new full attempt;
partial-suite diagnostics do not affect it.

The generated `.qualification-work/` directory and `QUALIFIED.json` are **local
consumer-side state**, not artifacts shipped or written back to S3. The release
archive files and `RELEASE.json`/`SHA256SUMS` are never rewritten. The marker
is a summary of the preserved evidence, not a replacement for verifying it.
Keep downloaded release directories writable by the qualification user.

When running an independently cloned qualification checkout outside the release,
select the bundle explicitly:

```bash
python qualify.py --bundle "$HOME/releases/cerplot-v0.1.10-linux"
```

`--work-dir` and `--python` remain optional overrides. A work directory outside
the release is supported; a work directory inside the release is allowed **only**
under `.qualification-work/`, never under packaged product directories.

The remote machine still needs NSE history, Python 3.11, the compatible GCC
toolchain, CMake, a supported native build tool, and RawInfra's external
libraries. `--timeout-build`, `--jobs`, and other existing options remain
available if the defaults are inappropriate for the machine.

Before running Runtime/NSE or `--suite all`, configure the remote machine's
`~/.cerplot.env` with `CERPLOT_DATA_ROOT` pointing to its historical capture
directory. `--data-root` is optional: it checks a directory exists but does
not replace the machine's Core configuration. The Runtime runner explicitly
selects the real machine env file while keeping HOME and XDG write locations
isolated; it generates a disposable project-local `CERPLOT_RUN_ROOT` override.
You can explicitly select an alternate file with `--machine-env-file FILE`.

RawInfra uses `g++` on PATH and its own CMake default `$HOME/ExternalLibraries`, where `libRawInfra` and `binarydg` are normally installed. The compiler major version is checked against the release. Override with `--cxx`, `--external-library-path`, `--base-raw-library-path`, or `--binary-dg-library` only for nonstandard machines. CMake chooses the native build generator; `--ninja` remains an optional explicit selection.

`--suite all` **always** runs **Python, Runtime in `full` mode, and RawInfra**. It reports `QUALIFIED REMOTE RELEASE` only if all three exit successfully and produce recognized, fully passing evidence bound to the **same** `RELEASE.json`, `SHA256SUMS`, and expected artifact hashes. Runtime preflight alone is never sufficient. Any failed, absent, partial or inconsistent child report fails the full release.

Each run creates a fresh independent workspace and keeps its evidence, logs and outputs. It never reuses previous CAS, SQLite, or research results. The runners print paths to the active logs at startup, emit a heartbeat every 60 seconds while commands are running, and write `latest-qualification.txt`, `latest-runtime.txt`, `latest-python.txt`, or `latest-rawinfra.txt` under their selected work-directory parent. These are text pointers, not reused execution directories.

To monitor the combined run from another terminal:

```bash
RUN=$(cat ../../.qualification-work/latest-qualification.txt)
tail -n 50 -F "$RUN/logs/runtime.log"
# For CerPlot Orchestrator logs after Runtime has started:
find "$RUN/runtime" -path '*/state/logs/*.jsonl' -print
```

To review old completed runs for cleanup (dry run):

```bash
python3 clean.py --work-dir ../../.qualification-work --keep 2
# Only when satisfied that old evidence is no longer needed:
python3 clean.py --work-dir ../../.qualification-work --keep 2 --apply
```

The cleanup tool only considers completed, qualification-named directories directly under the specified work directory, never active runs or unrelated files. Combined runs contain their nested suite evidence and are removed as one unit. It does not automatically delete prior runs. Inside the release, use only the designated `.qualification-work/` scratch directory; never put work directories inside packaged artifacts or historical data. The combined command currently needs all three suites' dependencies on one machine; aggregation of independently signed reports from multiple machines is **not** implemented.

### Run suites independently

```bash
python3 python/run.py \
  --bundle "$HOME/releases/cerplot-v0.1.10-linux" \
  --python /usr/bin/python3.11 \
  --work-dir "$HOME/cerplot-qualification-runs"

python3 runtime/run.py \
  --bundle "$HOME/releases/cerplot-v0.1.10-linux" \
  --work-dir "$HOME/cerplot-qualification-runs"

python3 rawinfra/run.py \
  --bundle "$HOME/releases/cerplot-v0.1.10-linux" \
  --work-dir "$HOME/cerplot-qualification-runs"
```

For diagnosis, the top-level command also accepts `--suite python`, `--suite runtime`, or `--suite rawinfra` with the corresponding arguments. A selected suite may pass on its own, but the top-level evidence is marked **not fully qualified**, and it does not print `QUALIFIED REMOTE RELEASE`. The Runtime suite itself also permits `--mode preflight` for debugging, which cannot qualify a release.

## Suite-specific limitations

- **Python:** The existing checks verify native module installation and imports, not every binding's functional semantics. Installation is offline (`--no-index --no-deps`); the Python environment must already contain appropriate wheel tooling.
- **Runtime/NSE:** Validates the shipped NSE `local` profile for **4 assets, 5 fit days and 2 test days**, runs a packaged `runtime-check` and preflight, then executes a full local build. It checks a published run snapshot and nonempty SQLite/CAS state. It does **not** independently prove the exact terminal status of every planned research shard or evaluate model R²; stronger assertions will be based on actual stable Results/Manifest records after a real run. See [runtime/README.md](runtime/README.md).
- **RawInfra:** Compiles and links the actual external Data and Live Drivers against the two extracted, ABI-compatible SDKs. **Neither CTest nor either production driver is executed** and no live order-routing session is started. Proprietary RawInfra dependencies must be installed on the consumer machine. This is not an operational/trading qualification.

The Runtime extractor supports contained ELF symlink chains and contained hard links, including forward references, but rejects traversal, escapes, dangling links, cycles, special file types, and attempts to write through extracted symbolic-link parents. Python and Runtime redirect `HOME`, XDG configuration/cache/data/state paths, and scratch state into their fresh run directories. RawInfra preserves the invoking machine's `HOME` so its normal CMake ExternalLibraries defaults work. All suites remove inherited CerPlot plugin overrides and relevant development environment variables. The Runtime suite also selects the invoking machine's `~/.cerplot.env` via Core's `CERPLOT_ENV_FILE` and overrides only the temporary research run root through a generated project env file; Python and RawInfra remain fully isolated from machine CerPlot configuration.

## Evidence

The combined runner writes:

```text
qualification-<timestamp>-<random>/
  evidence/qualification.json
  logs/{python,runtime,rawinfra}.log
  python/python-.../evidence/qualification.json
  runtime/runtime-.../evidence/qualification.json
  rawinfra/rawinfra-.../evidence/qualification.json
```

Each child evidence record includes its selected artifact checksum(s) and the hashes of `RELEASE.json` and `SHA256SUMS`. The combined report additionally verifies that every child represents the same release inventory and complete test mode. Large research CAS and build files remain in the qualification workspace, not in the customer release.

**This is independent remote acceptance, not a new stage of the official Rocky build/tag/S3 publication process.** In particular, CerPlot v0.1.8's prior producer-side qualification is unchanged. A genuine remote acceptance result requires executing these suites against the real downloaded v0.1.8 artifacts and client dependencies.

## Development/regression tests

```bash
python3 -m unittest discover -s python/devtests -p 'test_*.py' -v
python3 -m unittest discover -s runtime/devtests -p 'test_*.py' -v
python3 -m unittest discover -s rawinfra/devtests -p 'test_*.py' -v
python3 -m unittest discover -s devtests -p 'test_*.py' -v
```

These use small synthetic releases and mock providers; they verify runner control flow, failure handling, archive safety and report validation. They **do not** replace a real remote release qualification run. The repository itself should be version-controlled independently, and its exact tested Git revision recorded when later integrating remote qualification with the official release lifecycle.
