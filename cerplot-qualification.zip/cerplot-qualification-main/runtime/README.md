# CerPlot Runtime / NSE release qualification

This is the **Runtime suite** of the standalone `cerplot-qualification` repository. It uses only Python 3.11+ standard-library modules on Linux. It does not build CerPlot, use the SDK, clone repositories, contact GitHub, or run an NSE-specific launcher.

The input is an **official downloaded CerPlot release directory**, with `RELEASE.json`, `SHA256SUMS`, the `runtime/*.tar.gz`, and the `sources/config-nse-*.zip`. A locally assembled release using `artifacts/runtime/` and `artifacts/sources/` is also accepted. The Developer SDK and other optional downloads are not needed. The two input artifacts must match their `RELEASE.json` size/SHA-256 and the downloaded `SHA256SUMS` records. This checks local integrity, not the authenticity of the downloaded release; obtain the release through CerPlot's official verified download workflow.

## Command

```bash
python3 runtime/run.py \
    --bundle "$HOME/releases/cerplot-v0.1.10-linux" \
    --work-dir "$HOME/cerplot-qualification-runs"
```

The **default is `--mode full`**: unpack the exact released Runtime, unpack the exact released `config-nse` source ZIP, validate the NSE four-asset `local` profile, run the packaged `runtime-check`, then `inspect --project ... --profile=local --depth=preflight --format=json`, and finally `build --project ... --profile=local`. `build` must return 0 (CerPlot's complete research status) and publish one `CERPLOT::RUN_SNAPSHOT_PUBLISHED_V1` attempt in the isolated NSE project. The test verifies nonempty persisted SQLite results, SQLite manifests, and CAS files. It does **not** judge predictor R² or financial performance.

To iterate on packaging/configuration only, use `--mode preflight`; that mode emits `preflight-passed-not-full-qualification`, not `passed`. Build timeout defaults to two hours and is configurable with `--timeout-build SECONDS`. The local NSE scheduler uses `127.0.0.1:8082`; if another process holds that port the runner reports a failure rather than modifying the released scientific project. Avoid concurrent tests using the same port.

The runner expects the invoking machine's `~/.cerplot.env` to provide
`CERPLOT_DATA_ROOT`, pointing at the existing historical NSE capture directory.
For example, on the remote test machine:

```dotenv
CERPLOT_DATA_ROOT=/mnt/alpha_lustre/data_store/NSE_Stock/TickCapture
CERPLOT_RUN_ROOT=/home/user/cerplot-data
```

The machine file is read **by CerPlot Core**, not parsed to produce environment
substitutions by Python. Use `--machine-env-file /absolute/path/file.env` when
the intended machine file is somewhere other than `~/.cerplot.env`.
`--data-root /path/to/data` remains an optional directory-existence and
read-only overlap assertion, **not** a configuration override. The file must
still provide `CERPLOT_DATA_ROOT` to the packaged CerPlot process.

## Isolation and provenance

Every invocation creates a **new** `runtime-<timestamp>-<random>/` directory below `--work-dir`. Nothing is deleted. The release bundle and historical dataset are never written by this runner; the NSE project, work databases, logs, telemetry, snapshots, sandbox, and CAS all live in this new directory. With the combined runner's zero-argument default, the work directory is beneath the downloaded release's `.qualification-work/` scratch tree. Explicit work directories outside the release remain supported. Never write into packaged `runtime/`, `sources/` or historical data.

All inherited `CERPLOT_*` process settings and native loader overrides are scrubbed.
The runner supplies only the two **existing Core environment-file selectors**:

- `CERPLOT_ENV_FILE=<absolute path to the machine ~/.cerplot.env>` — supplies
  machine-specific data paths through Core's normal user-level dotenv layer
- `CERPLOT_CONFIG_ENV_FILE=envfiles/qualification.env` — selects a small
  generated file inside the **disposable NSE project** containing only
  `CERPLOT_RUN_ROOT=<fresh qualification state directory>`

The released `envfiles/config.local.linux.env` may be comment-only. It is not
required to refer to `CERPLOT_LOCAL_*`. The runner does not modify any existing
NSE configuration files, `CerPlot.toml`, `run/local.toml`, or `run/plugins.toml`.
It adds only the disposable `envfiles/qualification.env` beside them.
The temporary `HOME` and redirected `XDG_CONFIG_HOME`, `XDG_CACHE_HOME`,
`XDG_DATA_HOME`, and `XDG_STATE_HOME` keep generated state isolated, while
Core reads the explicitly selected machine env file. Active plugin overrides
in the machine or NSE local env file are rejected, so plugin paths still come
from the packaged Runtime's native registry resolver.

**The downloaded NSE ZIP must already contain the local profile and
native-plugin-default configuration.** The tested Git revision is read
from the release manifest; there is no separate `git pull` of `main`.

Runtime tar extraction supports internal ELF-style symbolic-link chains
(e.g. `libx.so → libx.so.1 → libx.so.1.0`) and regular-file hard links,
including forward references. Link targets are checked after the complete
symlink graph is constructed, but **no extracted link is followed during file
writes**. Traversal, escaping, dangling/cyclic links and special files are
rejected. A damaged archive fails qualification.

Each completed Runtime suite records the SHA-256 of `RELEASE.json` and
`SHA256SUMS`, so the combined runner can match it to Python and RawInfra
qualification of the exact same release inventory.

The runner reports:

```text
runtime-.../
  unpacked/runtime/...
  unpacked/nse/config-nse/...
  state/db/{journal,results,manifests,...}.sqlite
  state/cas/...
  home/
  logs/runtime-check.stdout.log
  logs/runtime-check.stderr.log
  logs/inspect.stdout.json
  logs/inspect.stderr.log
  logs/build.stdout.log
  logs/build.stderr.log
  evidence/{qualification,inspect}.json
```

Process stdout and stderr are captured independently. The inspection JSON is
parsed only from unmodified stdout; stderr contains Platform diagnostics,
including the `logging.summary` shutdown line. The build's
`CERPLOT::RUN_SNAPSHOT_PUBLISHED_V1` record is likewise read from stdout.
The qualification report's per-step `log` field identifies stdout and
`stderr_log` identifies the separate diagnostic log. No runner headers are
inserted into either stream.

Large run artifacts remain in the local qualification work directory, not in the immutable published archives. When using the combined runner's default, this is the download's `.qualification-work/` directory. Only `evidence/` and the relevant logs should be retained as long-term release proof; the runner itself does not decide retention policy or upload evidence. SQLite/CAS checks are lightweight integration evidence. More detailed result/terminal assertions can be added once they are grounded in the stable Results API, without changing this runner's package-selection or environment contracts.

The existing Rocky builder relocation, negative tests, and SDK checks remain separate and unchanged. This suite is intended for a **different remote qualification machine** and is not automatically a new Rocky release gate until release orchestration is explicitly updated.

## Test infrastructure

```bash
python3 -m unittest discover -s runtime/devtests -p 'test_*.py' -v
```

These tests validate artifact selection, archive safety, NSE profile checks, and the runner using synthetic fixtures. They do not substitute for running a genuine packaged CerPlot Runtime with historical NSE data.

### Live progress and current run

The runner prints the new run root and each command's stdout/stderr paths as soon as the command starts. Every 60 seconds it emits a progress heartbeat. It does not merge stdout and stderr (inspect stdout must remain valid JSON). In a second terminal, for a standalone Runtime run:

```bash
RUN=$(cat ~/cerplot-qualification-runs/latest-runtime.txt)
tail -n 50 -F "$RUN/logs/build.stderr.log"
find "$RUN/state/logs" -name '*.jsonl' -print
```

The run's SQLite/CAS/manifest state is always new; prior runs are retained until explicitly cleaned using the repository-level `clean.py` command. For the combined runner's default local layout, find the latest full run using `../../.qualification-work/latest-qualification.txt` from `qualification/cerplot-qualification/`.
