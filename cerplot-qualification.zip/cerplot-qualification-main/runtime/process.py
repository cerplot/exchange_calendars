"""Isolated process execution with timeout and process-group cleanup (Linux)."""
from __future__ import annotations

import os
import signal
import subprocess
import sys
import time
from pathlib import Path


def isolated_env(home: Path, machine_env_file: Path) -> dict[str, str]:
    env = dict(os.environ)
    for key in list(env):
        if (key.startswith(("CERPLOT_", "VCPKG_")) or key in {
            "PYTHONPATH", "PYTHONHOME", "PYTHONUSERBASE", "LD_LIBRARY_PATH",
            "LD_PRELOAD", "LD_AUDIT", "CONDA_PREFIX", "VIRTUAL_ENV"}):
            env.pop(key)
    # All XDG state stays under the fresh per-run home. Do not inherit the
    # developer's data/state directories, even if provided by the login shell.
    for relative in (".config", ".cache", ".local/share", ".local/state", "tmp"):
        (home / relative).mkdir(parents=True, mode=0o700, exist_ok=True)
    env.update({
        "HOME": str(home),
        "USERPROFILE": str(home),
        "XDG_CONFIG_HOME": str(home / ".config"),
        "XDG_CACHE_HOME": str(home / ".cache"),
        "XDG_DATA_HOME": str(home / ".local/share"),
        "XDG_STATE_HOME": str(home / ".local/state"),
        "TMPDIR": str(home / "tmp"),
        # Let Core read the real machine defaults even though HOME remains
        # isolated for every other user-level cache/configuration source.
        "CERPLOT_ENV_FILE": str(machine_env_file),
        # Generated in the disposable extracted NSE project by runtime/run.py.
        "CERPLOT_CONFIG_ENV_FILE": "envfiles/qualification.env",
    })
    return env


def execute(label: str, command: list[str], cwd: Path, env: dict[str, str],
            output: Path, timeout: int) -> dict:
    """Capture pristine stdout and independent stderr, including on failure.

    `output` names the stdout file. Diagnostic messages must never be merged
    into an inspect JSON document or a build lifecycle record.
    """
    start = time.monotonic()
    return_code = None
    timed_out = False
    stderr_path = output.with_name(label + ".stderr.log")
    with output.open("wb") as stdout_log, stderr_path.open("wb") as stderr_log:
        proc = subprocess.Popen(command, cwd=cwd, env=env,
                                stdout=stdout_log, stderr=stderr_log,
                                start_new_session=True)
        try:
            deadline = start + timeout
            while True:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise subprocess.TimeoutExpired(command, timeout)
                try:
                    return_code = proc.wait(timeout=min(60, remaining))
                    break
                except subprocess.TimeoutExpired:
                    if time.monotonic() >= deadline:
                        raise
                    print(f"[{label}] still running ({int(time.monotonic() - start)}s); "
                          f"stderr: {stderr_path}", file=sys.stderr, flush=True)
        except subprocess.TimeoutExpired:
            timed_out = True
            os.killpg(proc.pid, signal.SIGTERM)
            try:
                return_code = proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid, signal.SIGKILL)
                return_code = proc.wait()
    return {"name": label,
            "status": "passed" if return_code == 0 and not timed_out else "failed",
            "exit_code": return_code, "timed_out": timed_out,
            "duration_seconds": round(time.monotonic() - start, 3),
            "log": "logs/" + output.name,
            "stderr_log": "logs/" + stderr_path.name}
