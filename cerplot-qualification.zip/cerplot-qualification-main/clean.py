#!/usr/bin/env python3
"""List or remove completed old qualification runs; never touch active runs."""
from __future__ import annotations

import argparse
import json
import os
import re
import shutil
from pathlib import Path

KINDS = ("qualification", "python", "runtime", "rawinfra")
RUN_PATTERN = re.compile(r"^(qualification|python|runtime|rawinfra)-\d{8}T\d{6}Z-[a-f0-9]{8,10}$")


def candidates(parent: Path, keep: int) -> list[Path]:
    if parent.is_symlink() or not parent.is_dir():
        raise ValueError("work directory must exist and must not be a symlink")
    old: list[Path] = []
    for kind in KINDS:
        roots = sorted((p for p in parent.iterdir() if p.is_dir() and not p.is_symlink()
                        and RUN_PATTERN.fullmatch(p.name) and p.name.startswith(kind + "-")),
                       key=lambda p: p.name, reverse=True)
        for root in roots[keep:]:
            if root.resolve() != (parent.resolve() / root.name):
                continue
            if root.stat().st_uid != os.getuid():
                continue
            report = root / "evidence/qualification.json"
            if not report.is_file() or report.is_symlink():
                continue
            try:
                data = json.loads(report.read_text(encoding="utf-8"))
            except (OSError, ValueError):
                continue
            # In-progress runs have no completion timestamp. Never remove them.
            if isinstance(data, dict) and data.get("completed_utc") and data.get("status"):
                old.append(root)
    return old


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--work-dir", type=Path, required=True)
    parser.add_argument("--keep", type=int, default=2,
                        help="Preserve at least this many latest directories per suite (default: 2)")
    parser.add_argument("--apply", action="store_true", help="Delete listed completed runs")
    args = parser.parse_args(argv)
    if args.keep < 1:
        parser.error("--keep must be at least 1")
    parent = args.work_dir.expanduser().absolute()
    try:
        selected = candidates(parent, args.keep)
    except (OSError, ValueError) as exc:
        parser.error(str(exc))
    for root in selected:
        print(("REMOVING " if args.apply else "WOULD REMOVE ") + str(root), flush=True)
        if args.apply:
            shutil.rmtree(root)
    if not args.apply:
        print("Dry run only; add --apply to remove completed old runs.")
    print(f"{len(selected)} completed run(s) selected")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
