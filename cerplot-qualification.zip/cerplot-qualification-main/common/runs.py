"""Discover the last invocation without reusing any previous execution state."""
from __future__ import annotations

import os
from pathlib import Path


def remember_run(parent: Path, kind: str, run: Path) -> Path:
    """Publish a readable pointer, never a symlink to mutable qualification data."""
    pointer = parent / f"latest-{kind}.txt"
    if pointer.is_symlink():
        raise OSError(f"latest-run pointer must not be a symlink: {pointer}")
    temporary = parent / f".{pointer.name}.{run.name}.tmp"
    try:
        temporary.write_text(str(run.resolve(strict=True)) + "\n", encoding="utf-8")
        os.replace(temporary, pointer)
    finally:
        temporary.unlink(missing_ok=True)
    return pointer


def require_safe_work_parent(bundle: Path, parent: Path) -> None:
    """Protect release inputs while allowing only .qualification-work inside them."""
    bundle = bundle.resolve(strict=True)
    literal_parent = parent.expanduser().absolute()
    normalized = literal_parent.resolve(strict=False)

    if normalized == bundle or bundle.is_relative_to(normalized):
        raise ValueError("qualification work directory contains the release bundle")

    # An explicitly release-local path must not escape through links or `..`.
    if literal_parent.is_relative_to(bundle):
        scratch = bundle / ".qualification-work"
        if not literal_parent.is_relative_to(scratch):
            raise ValueError("work inside the release must be beneath .qualification-work")
        current = bundle
        for part in literal_parent.relative_to(bundle).parts:
            current = current / part
            if current.is_symlink():
                raise ValueError("qualification scratch directory cannot contain symlinks")
        if not normalized.is_relative_to(scratch):
            raise ValueError("qualification scratch directory escapes the release")

    if normalized.is_relative_to(bundle):
        if not normalized.is_relative_to(bundle / ".qualification-work"):
            raise ValueError("work inside the release must be beneath .qualification-work")
