#!/usr/bin/env python3
"""Run remote Python, Runtime/NSE and RawInfra acceptance against one release.

Individual suites support diagnosis. Only `--suite all` with three passing,
full-mode suites and one common verified artifact inventory qualifies a release.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4

from common.artifacts import BundleError, release_identity
from common.environment import prepare_isolation, run_logged
from common.reporting import Report, write_json
from common.runs import remember_run, require_safe_work_parent

HERE = Path(__file__).resolve().parent
REVISION = "remote-bundle-v3"
ALL_SUITES = ("python", "runtime", "rawinfra")


def discover_bundle(script: Path | None = None) -> Path:
    """Find the downloaded release enclosing the extracted qualification suite."""
    for candidate in (script or Path(__file__)).absolute().parents:
        if (candidate / "RELEASE.json").is_file() and (candidate / "SHA256SUMS").is_file():
            return candidate
    raise ValueError("cannot find release above qualify.py; supply --bundle")


def qualification_marker(bundle: Path) -> Path:
    return bundle / "QUALIFIED.json"


def clear_qualification_marker(bundle: Path) -> None:
    """A fresh full attempt invalidates a previous local pass marker."""
    marker = qualification_marker(bundle)
    if marker.is_symlink():
        raise ValueError("QUALIFIED.json cannot be a symlink")
    if marker.exists():
        if not marker.is_file():
            raise ValueError("QUALIFIED.json must be a regular file")
        marker.unlink()


def publish_qualification_marker(bundle: Path, identity: dict, evidence: Path,
                                 suites: dict) -> Path:
    marker = qualification_marker(bundle)
    if marker.exists() or marker.is_symlink():
        raise ValueError("qualification marker appeared during the test")
    location = (str(evidence.relative_to(bundle)) if evidence.is_relative_to(bundle)
                else str(evidence))
    write_json(marker, {
        "format": "cerplot-remote-qualification-marker-v1",
        "release_version": identity["version"],
        "status": "passed",
        "release_manifest_sha256": identity["release_manifest_sha256"],
        "release_checksums_sha256": identity["release_checksums_sha256"],
        "completed_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "evidence": location,
        "suites": {name: suites[name]["status"] for name in ALL_SUITES},
    })
    return marker


FORMATS = {
    "python": "cerplot-python-qualification-v1",
    "runtime": "cerplot-runtime-nse-qualification-v1",
    "rawinfra": "cerplot-rawinfra-consumer-qualification-v1",
}


def _require_artifact(identity: dict, relative: str, digest: str, label: str) -> None:
    if (not isinstance(relative, str) or not isinstance(digest, str)
            or identity["artifacts"].get(relative) != digest):
        raise ValueError(f"{label} does not match RELEASE.json artifact inventory")
    locations = (relative, "artifacts/" + relative)
    checksums = identity["checksum_entries"]
    present = [path for path in locations if path in checksums]
    if len(present) != 1 or checksums[present[0]] != digest:
        raise ValueError(f"{label} does not match SHA256SUMS")


def _require_release_identity(content: dict, identity: dict, suite: str) -> None:
    if content.get("format") != FORMATS[suite] or content.get("status") != "passed":
        raise ValueError(f"{suite} did not supply passing, recognized suite evidence")
    if content.get("release_version") != identity["version"]:
        raise ValueError(f"{suite} reported a different release version")
    for field in ("release_manifest_sha256", "release_checksums_sha256"):
        if content.get(field) != identity[field]:
            raise ValueError(f"{suite} reported a different release inventory ({field})")
    if suite == "python":
        if content.get("test_selection") != "all" or content.get("development_selection"):
            raise ValueError("Python suite was not run with all tests")
        tests = content.get("tests")
        if not isinstance(tests, dict) or tests.get("status") != "passed" or tests.get("executed", 0) < 1:
            raise ValueError("Python suite lacks passing test evidence")
        rel = content.get("wheel_path")
        if not isinstance(rel, str) or not re.fullmatch(r"python/cerplot-[^/]+manylinux_[^/]+\.whl", rel):
            raise ValueError("Python suite did not report the released repaired wheel")
        _require_artifact(identity, rel, content.get("wheel_sha256"), "Python wheel")
    elif suite == "runtime":
        if content.get("mode") != "full":
            raise ValueError("Runtime must run in full mode (preflight is not qualification)")
        steps = content.get("steps")
        if (not isinstance(steps, list) or [step.get("name") for step in steps
                if isinstance(step, dict)] != ["runtime-check", "inspect", "build"]
                or any(not isinstance(step, dict) or step.get("status") != "passed" for step in steps)):
            raise ValueError("Runtime lacks passing full-build step evidence")
        if not isinstance(content.get("snapshot"), dict) or not isinstance(content.get("outputs"), dict):
            raise ValueError("Runtime lacks full research completion evidence")
        rel = content.get("runtime_artifact")
        if not isinstance(rel, str) or not re.fullmatch(r"runtime/cerplot-[^/]+-linux-x86_64-Release\.tar\.gz", rel):
            raise ValueError("Runtime suite did not report the released Runtime archive")
        _require_artifact(identity, rel, content.get("runtime_sha256"), "Runtime")
        commit = content.get("nse_config_commit")
        if not isinstance(commit, str) or not re.fullmatch(r"[a-f0-9]{40}", commit):
            raise ValueError("Runtime lacks the pinned config-nse commit")
        # The Git commit is part of RELEASE.json, not inferred from the ZIP name.
        if commit != identity["source_commits"].get("config-nse"):
            raise ValueError("Runtime config-nse source revision differs from release")
        nse_rel = f"sources/config-nse-{commit[:12]}.zip"
        _require_artifact(identity, nse_rel, content.get("nse_archive_sha256"), "config-nse")
    elif suite == "rawinfra":
        if content.get("run_policy") != "build-and-link-only;no-driver-execution":
            raise ValueError("RawInfra suite did not use the build-and-link-only policy")
        steps = content.get("steps")
        if (not isinstance(steps, list)
                or [step.get("name") for step in steps if isinstance(step, dict)] != ["configure", "build"]
                or any(not isinstance(step, dict) or step.get("status") != "passed"
                       for step in steps)):
            raise ValueError("RawInfra lacks successful configure/build step evidence")
        binaries = content.get("built_executables")
        expected_binaries = {"src/data-driver/data_capture_exe", "src/live-driver/live_driver"}
        if (not isinstance(binaries, dict) or set(binaries) != expected_binaries
                or any(not isinstance(record, dict)
                       or type(record.get("bytes")) is not int or record["bytes"] <= 0
                       or not isinstance(record.get("sha256"), str)
                       or not re.fullmatch(r"[0-9a-f]{64}", record["sha256"])
                       for record in binaries.values())):
            raise ValueError("RawInfra lacks evidence of both linked driver executables")
        commit = content.get("source_commit")
        if commit != identity["source_commits"].get("cerplot-rawinfra"):
            raise ValueError("RawInfra source revision differs from release")
        entries = content.get("artifacts")
        if not isinstance(entries, dict) or set(entries) != {"capture_sdk", "live_sdk", "rawinfra_source"}:
            raise ValueError("RawInfra did not report all three released inputs")
        expected = {
            "capture_sdk": rf"capture_sdk/cerplot-capture-sdk-{re.escape(identity['version'][1:])}-linux-x86_64-Release\.tar\.gz",
            "live_sdk": rf"live_sdk/cerplot-live-sdk-{re.escape(identity['version'][1:])}-linux-x86_64-Release\.tar\.gz",
            "rawinfra_source": rf"sources/cerplot-rawinfra-{commit[:12]}\.zip",
        }
        for label, item in entries.items():
            if not isinstance(item, dict):
                raise ValueError("RawInfra artifact evidence is malformed")
            rel = item.get("relative_path")
            if not isinstance(rel, str) or not re.fullmatch(expected[label], rel):
                raise ValueError("RawInfra has an unexpected " + label + " artifact")
            _require_artifact(identity, rel, item.get("sha256"), label)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bundle", type=Path,
                        help="Downloaded release root (default: find above qualify.py)")
    parser.add_argument("--work-dir", type=Path,
                        help="Qualification run parent (default: <release>/.qualification-work)")
    parser.add_argument("--suite", choices=("all", *ALL_SUITES), default="all")
    parser.add_argument("--python", type=Path, default=Path(sys.executable),
                        help="Python interpreter for wheel qualification (default: current interpreter)")
    parser.add_argument("--machine-env-file", type=Path,
                        help="Machine CerPlot env file (default: invoking user's ~/.cerplot.env)")
    parser.add_argument("--data-root", type=Path,
                        help="Optional historical-data directory assertion (not a config override)")
    parser.add_argument("--external-library-path", type=Path,
                        help="RawInfra client ExternalLibraries directory")
    parser.add_argument("--base-raw-library-path", type=Path)
    parser.add_argument("--binary-dg-library", type=Path)
    parser.add_argument("--cxx", default="g++")
    parser.add_argument("--cmake", default="cmake")
    parser.add_argument("--ninja", help="Optional Ninja executable; otherwise CMake selects its generator")
    parser.add_argument("--jobs", type=int, default=4)
    parser.add_argument("--timeout", type=int, default=1800,
                        help="Per-command timeout for Python and RawInfra")
    parser.add_argument("--timeout-build", type=int, default=7200,
                        help="Runtime/NSE full research-build timeout")
    parser.add_argument("--timeout-smoke", type=int, default=120,
                        help="Runtime-check and NSE inspect timeouts")
    args = parser.parse_args(argv)
    selected = ALL_SUITES if args.suite == "all" else (args.suite,)
    # Resolve the release first, including when invoked with no arguments.
    # Any new full attempt immediately invalidates its previous local marker.
    try:
        bundle = (args.bundle.expanduser() if args.bundle is not None
                  else discover_bundle()).resolve(strict=True)
        if not bundle.is_dir():
            raise ValueError("release bundle is not a directory")
        parent = (args.work_dir.expanduser() if args.work_dir is not None
                  else bundle / ".qualification-work").absolute()
        require_safe_work_parent(bundle, parent)
        if args.suite == "all":
            clear_qualification_marker(bundle)
    except (OSError, ValueError) as exc:
        parser.error(str(exc))

    if "python" in selected and not args.python.is_file():
        parser.error("--python must identify an existing interpreter for the Python suite")
    if "runtime" in selected:
        machine_env_file = (args.machine_env_file or (Path.home() / ".cerplot.env")).expanduser()
        if not machine_env_file.is_file():
            parser.error("Runtime requires a machine ~/.cerplot.env (or --machine-env-file)")
        machine_env_file = machine_env_file.resolve(strict=True)
        if args.data_root is not None and not args.data_root.expanduser().is_dir():
            parser.error("--data-root assertion must identify an existing data directory")
        if machine_env_file.is_relative_to(parent.resolve()):
            parser.error("qualification work directory must not contain the machine environment file")
        if args.data_root is not None:
            data_root = args.data_root.expanduser().resolve(strict=True)
            if (data_root.is_relative_to(parent.resolve())
                    or parent.resolve().is_relative_to(data_root)):
                parser.error("qualification work directory must not overlap historical data")
    if min(args.jobs, args.timeout, args.timeout_build, args.timeout_smoke) < 1:
        parser.error("jobs and timeouts must be positive")
    try:
        parent.mkdir(parents=True, exist_ok=True)
        if parent.is_symlink():
            raise ValueError("work directory cannot be a symlink")
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        root = parent / f"qualification-{stamp}-{uuid4().hex[:8]}"
        root.mkdir(mode=0o700, exist_ok=False)
        pointer = remember_run(parent, "qualification", root)
        env = prepare_isolation(root)
    except (OSError, ValueError) as exc:
        print(f"QUALIFICATION SETUP FAILED: {exc}", file=sys.stderr)
        return 1
    print(f"Qualification run: {root}", flush=True)
    print(f"Latest run pointer: {pointer}", flush=True)
    print(f"Combined logs: {root / 'logs'}", flush=True)
    report = Report(root / "evidence/qualification.json", REVISION,
                    evidence_format="cerplot-remote-bundle-qualification-v1")
    report.data.update({"selection": args.suite, "release_bundle": str(bundle), "suites": {}})
    report.save()
    try:
        identity = release_identity(bundle)
        release = json.loads((bundle / "RELEASE.json").read_text(encoding="utf-8"))
        sources = release.get("source_repositories", {})
        if not isinstance(sources, dict):
            raise ValueError("release source inventory is malformed")
        identity["source_commits"] = {label: item.get("commit") for label, item in sources.items()
                                      if isinstance(item, dict)}
        report.data.update({key: identity[key] for key in (
            "release_manifest_sha256", "release_checksums_sha256")})
        report.data["release_version"] = identity["version"]
        report.save()
        for selection in selected:
            work = root / selection
            work.mkdir(mode=0o700)
            cmd = [sys.executable, str(HERE / selection / "run.py"),
                   "--bundle", str(bundle), "--work-dir", str(work)]
            if selection == "python":
                cmd += ["--python", str(args.python.expanduser().absolute()), "--timeout", str(args.timeout)]
                deadline = args.timeout * 5 + 120
            elif selection == "runtime":
                cmd += ["--machine-env-file", str(machine_env_file),
                        "--mode", "full", "--timeout-build", str(args.timeout_build),
                        "--timeout-smoke", str(args.timeout_smoke)]
                if args.data_root is not None:
                    cmd += ["--data-root", str(args.data_root.expanduser().resolve(strict=True))]
                deadline = args.timeout_build + args.timeout_smoke * 2 + 120
            else:
                cmd += ["--timeout", str(args.timeout)]
                if args.external_library_path is not None:
                    cmd += ["--external-library-path", str(args.external_library_path)]
                for option, path in (("--base-raw-library-path", args.base_raw_library_path),
                                     ("--binary-dg-library", args.binary_dg_library)):
                    if path is not None:
                        cmd += [option, str(path)]
                cmd += ["--cxx", args.cxx, "--cmake", args.cmake,
                        "--jobs", str(args.jobs)]
                if args.ninja is not None:
                    cmd += ["--ninja", args.ninja]
                deadline = args.timeout * 2 + 120
            print(f"[{selection}] START — log: {root / 'logs' / (selection + '.log')}", flush=True)
            suite_env = dict(env)
            if selection == "rawinfra":
                # RawInfra CMake intentionally uses the invoking machine's
                # $HOME/ExternalLibraries. Other suites keep isolated HOME.
                suite_env["HOME"] = str(Path.home())
            result = run_logged(name=selection, argv=cmd, cwd=root, env=suite_env,
                                logs=root / "logs", timeout=deadline)
            print(f"[{selection}] {result['status'].upper()} ({result['seconds']:.1f}s)", flush=True)
            report.add_step(result)
            children = [p for p in work.iterdir() if p.is_dir() and not p.is_symlink()]
            evidence = children[0] / "evidence/qualification.json" if len(children) == 1 else None
            if evidence is None or not evidence.is_file() or evidence.is_symlink():
                raise ValueError(f"{selection} did not produce exactly one regular evidence file")
            content = json.loads(evidence.read_text(encoding="utf-8"))
            if not isinstance(content, dict):
                raise ValueError(f"{selection} suite evidence is not a JSON object")
            report.data["suites"][selection] = {
                "status": content.get("status"), "release_version": content.get("release_version"),
                "release_manifest_sha256": content.get("release_manifest_sha256"),
                "release_checksums_sha256": content.get("release_checksums_sha256"),
                "evidence": str(evidence), "run_dir": str(children[0]),
            }
            report.save()
            if result["status"] != "passed":
                raise ValueError(f"{selection} suite execution failed; see {result['log']}")
            _require_release_identity(content, identity, selection)
            current = release_identity(bundle)
            if any(current[k] != identity[k] for k in
                   ("version", "release_manifest_sha256", "release_checksums_sha256", "artifacts")):
                raise ValueError("release inventory changed during qualification")
        if args.suite == "all":
            if set(report.data["suites"]) != set(ALL_SUITES):
                raise ValueError("full qualification requires all three suites")
            report.finish(True)
            marker = publish_qualification_marker(bundle, identity, report.path, report.data["suites"])
            print(f"QUALIFIED REMOTE RELEASE: {identity['version']}")
            print(f"Marker: {marker}")
        else:
            report.finish(False, "partial suite selection is not full remote release qualification")
            print(f"COMPONENT SUITE PASSED (not full qualification): {args.suite}")
        print(f"Evidence: {report.path}")
        return 0
    except (OSError, ValueError, BundleError, TypeError, json.JSONDecodeError) as exc:
        report.finish(False, str(exc))
        print(f"REMOTE RELEASE QUALIFICATION FAILED: {exc}", file=sys.stderr)
        print(f"Evidence: {report.path}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
